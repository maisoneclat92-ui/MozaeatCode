import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';
import { registerUser, loginUser, getUserFromToken, verifyToken } from '@/lib/auth';
import { seedDemoRestaurant } from '@/lib/seedData';
import stripe, { PLANS, createCheckoutSession, createPortalSession, getOrCreatePrice } from '@/lib/stripe';

// Store SSE connections per restaurant
const restaurantClients = new Map();

// Notify clients of a specific restaurant
function notifyRestaurantClients(restaurantId, data) {
  const clients = restaurantClients.get(restaurantId) || new Set();
  clients.forEach(client => {
    try {
      client.enqueue(`data: ${JSON.stringify(data)}\n\n`);
    } catch (e) {
      clients.delete(client);
    }
  });
}

async function handleRequest(request, context) {
  const { params } = context;
  const pathSegments = params?.path || [];
  const path = '/' + pathSegments.join('/');
  const method = request.method;
  const url = new URL(request.url);

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  if (method === 'OPTIONS') {
    return new NextResponse(null, { status: 204, headers: corsHeaders });
  }

  try {
    const db = await getDb();

    // Health check
    if (path === '/health' && method === 'GET') {
      return NextResponse.json({ status: 'ok', timestamp: new Date().toISOString() }, { headers: corsHeaders });
    }

    // Seed demo data
    if (path === '/seed' && method === 'POST') {
      const restaurant = await seedDemoRestaurant();
      return NextResponse.json({ success: true, restaurant }, { headers: corsHeaders });
    }

    // ==================== AUTH ====================
    
    // Register
    if (path === '/auth/register' && method === 'POST') {
      const body = await request.json();
      const { name, email, password, restaurantName } = body;
      
      if (!name || !email || !password || !restaurantName) {
        return NextResponse.json({ error: 'Todos os campos são obrigatórios' }, { status: 400, headers: corsHeaders });
      }
      
      try {
        const result = await registerUser({ name, email, password, restaurantName });
        return NextResponse.json(result, { status: 201, headers: corsHeaders });
      } catch (error) {
        return NextResponse.json({ error: error.message }, { status: 400, headers: corsHeaders });
      }
    }

    // Login
    if (path === '/auth/login' && method === 'POST') {
      const body = await request.json();
      const { email, password } = body;
      
      try {
        const result = await loginUser({ email, password });
        return NextResponse.json(result, { headers: corsHeaders });
      } catch (error) {
        return NextResponse.json({ error: error.message }, { status: 401, headers: corsHeaders });
      }
    }

    // Get current user
    if (path === '/auth/me' && method === 'GET') {
      const authHeader = request.headers.get('Authorization');
      const token = authHeader?.replace('Bearer ', '');
      
      if (!token) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return NextResponse.json({ error: 'Token inválido' }, { status: 401, headers: corsHeaders });
      }
      
      return NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        },
        restaurant: user.restaurant
      }, { headers: corsHeaders });
    }

    // ==================== PUBLIC ROUTES (by restaurant slug) ====================
    
    // Get restaurant by slug
    if (path.match(/^\/r\/[\w-]+$/) && method === 'GET') {
      const slug = pathSegments[1];
      const restaurant = await db.collection('restaurants').findOne({ slug });
      
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      return NextResponse.json({
        id: restaurant.id,
        name: restaurant.name,
        slug: restaurant.slug,
        description: restaurant.description,
        logo: restaurant.logo,
        colorTheme: restaurant.colorTheme
      }, { headers: corsHeaders });
    }

    // Get menu by restaurant slug
    if (path.match(/^\/r\/[\w-]+\/menu$/) && method === 'GET') {
      const slug = pathSegments[1];
      const restaurant = await db.collection('restaurants').findOne({ slug });
      
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const categories = await db.collection('categories')
        .find({ restaurantId: restaurant.id })
        .sort({ order: 1 })
        .toArray();
      
      const products = await db.collection('products')
        .find({ restaurantId: restaurant.id, available: true })
        .toArray();
      
      const menu = categories.map(cat => ({
        ...cat,
        products: products.filter(p => p.categoryId === cat.id)
      }));
      
      return NextResponse.json({ restaurant, menu }, { headers: corsHeaders });
    }

    // Get table info by restaurant slug
    if (path.match(/^\/r\/[\w-]+\/mesa\/\d+$/) && method === 'GET') {
      const slug = pathSegments[1];
      const tableNumber = parseInt(pathSegments[3]);
      
      const restaurant = await db.collection('restaurants').findOne({ slug });
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const table = await db.collection('tables').findOne({ 
        restaurantId: restaurant.id, 
        number: tableNumber 
      });
      
      if (!table) {
        return NextResponse.json({ error: 'Mesa não encontrada' }, { status: 404, headers: corsHeaders });
      }
      
      return NextResponse.json({ restaurant, table }, { headers: corsHeaders });
    }

    // Get orders for a specific table (Comanda Viva)
    if (path.match(/^\/r\/[\w-]+\/mesa\/\d+\/orders$/) && method === 'GET') {
      const slug = pathSegments[1];
      const tableNumber = parseInt(pathSegments[3]);
      
      const restaurant = await db.collection('restaurants').findOne({ slug });
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const table = await db.collection('tables').findOne({ 
        restaurantId: restaurant.id, 
        number: tableNumber 
      });
      
      if (!table) {
        return NextResponse.json({ error: 'Mesa não encontrada' }, { status: 404, headers: corsHeaders });
      }
      
      // Get today's orders for this table (or orders with status != delivered in last 4 hours)
      const fourHoursAgo = new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString();
      const orders = await db.collection('orders')
        .find({ 
          restaurantId: restaurant.id, 
          tableNumber: tableNumber,
          createdAt: { $gte: fourHoursAgo }
        })
        .sort({ createdAt: -1 })
        .toArray();
      
      const total = orders.reduce((sum, order) => sum + order.total, 0);
      
      return NextResponse.json({ 
        orders, 
        total,
        table,
        restaurant: { name: restaurant.name, slug: restaurant.slug }
      }, { headers: corsHeaders });
    }

    // Call waiter or request bill
    if (path.match(/^\/r\/[\w-]+\/mesa\/\d+\/call$/) && method === 'POST') {
      const slug = pathSegments[1];
      const tableNumber = parseInt(pathSegments[3]);
      const body = await request.json();
      const { type, paymentMethod } = body; // type: 'waiter' | 'bill'
      
      const restaurant = await db.collection('restaurants').findOne({ slug });
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const table = await db.collection('tables').findOne({ 
        restaurantId: restaurant.id, 
        number: tableNumber 
      });
      
      if (!table) {
        return NextResponse.json({ error: 'Mesa não encontrada' }, { status: 404, headers: corsHeaders });
      }
      
      // Create alert
      const alert = {
        id: uuidv4(),
        restaurantId: restaurant.id,
        tableNumber,
        type, // 'waiter' or 'bill'
        paymentMethod: type === 'bill' ? paymentMethod : null,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      
      await db.collection('alerts').insertOne(alert);
      
      // Notify kitchen/admin
      notifyRestaurantClients(restaurant.id, { 
        type: type === 'waiter' ? 'waiter_call' : 'bill_request', 
        alert 
      });
      
      return NextResponse.json(alert, { status: 201, headers: corsHeaders });
    }

    // Create order (public - by restaurant slug)
    if (path.match(/^\/r\/[\w-]+\/orders$/) && method === 'POST') {
      const slug = pathSegments[1];
      const body = await request.json();
      const { tableNumber, items } = body;
      
      const restaurant = await db.collection('restaurants').findOne({ slug });
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const table = await db.collection('tables').findOne({ 
        restaurantId: restaurant.id, 
        number: tableNumber 
      });
      
      if (!table) {
        return NextResponse.json({ error: 'Mesa não encontrada' }, { status: 400, headers: corsHeaders });
      }
      
      // Get products and calculate totals
      const productIds = items.map(i => i.productId);
      const products = await db.collection('products')
        .find({ id: { $in: productIds }, restaurantId: restaurant.id })
        .toArray();
      
      const enrichedItems = items.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) throw new Error(`Produto não encontrado: ${item.productId}`);
        return {
          productId: item.productId,
          name: product.name,
          price: product.price,
          quantity: item.quantity,
          notes: item.notes || '',
          subtotal: product.price * item.quantity
        };
      });
      
      const total = enrichedItems.reduce((sum, item) => sum + item.subtotal, 0);
      
      const order = {
        id: uuidv4(),
        restaurantId: restaurant.id,
        tableId: table.id,
        tableNumber: table.number,
        items: enrichedItems,
        status: 'new',
        total,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      await db.collection('orders').insertOne(order);
      notifyRestaurantClients(restaurant.id, { type: 'new_order', order });
      
      return NextResponse.json(order, { status: 201, headers: corsHeaders });
    }

    // ==================== ADMIN ROUTES (protected) ====================
    
    // Helper to get authenticated restaurant
    const getAuthRestaurant = async () => {
      const authHeader = request.headers.get('Authorization');
      const token = authHeader?.replace('Bearer ', '');
      if (!token) return null;
      
      const payload = verifyToken(token);
      if (!payload) return null;
      
      return await db.collection('restaurants').findOne({ id: payload.restaurantId });
    };

    // SSE Stream for restaurant orders
    if (path === '/admin/orders/stream' && method === 'GET') {
      const authHeader = request.headers.get('Authorization');
      const token = authHeader?.replace('Bearer ', '');
      const payload = token ? verifyToken(token) : null;
      
      // Also allow query param for SSE (since headers can be tricky)
      const restaurantId = payload?.restaurantId || url.searchParams.get('restaurantId');
      
      if (!restaurantId) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const stream = new TransformStream();
      const writer = stream.writable.getWriter();
      const encoder = new TextEncoder();
      
      const controller = {
        enqueue: (data) => {
          writer.write(encoder.encode(data));
        }
      };
      
      if (!restaurantClients.has(restaurantId)) {
        restaurantClients.set(restaurantId, new Set());
      }
      restaurantClients.get(restaurantId).add(controller);
      
      writer.write(encoder.encode('data: {"type":"connected"}\n\n'));
      
      const pingInterval = setInterval(() => {
        try {
          writer.write(encoder.encode('data: {"type":"ping"}\n\n'));
        } catch (e) {
          clearInterval(pingInterval);
          restaurantClients.get(restaurantId)?.delete(controller);
        }
      }, 30000);
      
      request.signal.addEventListener('abort', () => {
        clearInterval(pingInterval);
        restaurantClients.get(restaurantId)?.delete(controller);
        writer.close();
      });

      return new Response(stream.readable, {
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    // Get alerts for restaurant (waiter calls, bill requests)
    if (path === '/admin/alerts' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const alerts = await db.collection('alerts')
        .find({ restaurantId: restaurant.id, status: 'pending' })
        .sort({ createdAt: -1 })
        .toArray();
      
      return NextResponse.json(alerts, { headers: corsHeaders });
    }

    // Dismiss alert
    if (path.match(/^\/admin\/alerts\/[\w-]+\/dismiss$/) && method === 'PATCH') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const alertId = pathSegments[2];
      
      const result = await db.collection('alerts').findOneAndUpdate(
        { id: alertId, restaurantId: restaurant.id },
        { $set: { status: 'dismissed', dismissedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      if (!result) {
        return NextResponse.json({ error: 'Alerta não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      notifyRestaurantClients(restaurant.id, { type: 'alert_dismissed', alertId });
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // Get orders for restaurant
    if (path === '/admin/orders' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const status = url.searchParams.get('status');
      const query = { restaurantId: restaurant.id };
      if (status) query.status = status;
      
      const orders = await db.collection('orders')
        .find(query)
        .sort({ createdAt: -1 })
        .toArray();
      
      return NextResponse.json(orders, { headers: corsHeaders });
    }

    // Update order status
    if (path.match(/^\/admin\/orders\/[\w-]+\/status$/) && method === 'PATCH') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const orderId = pathSegments[2];
      const body = await request.json();
      const { status } = body;
      
      const validStatuses = ['new', 'preparing', 'ready', 'delivered'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ error: 'Status inválido' }, { status: 400, headers: corsHeaders });
      }
      
      const result = await db.collection('orders').findOneAndUpdate(
        { id: orderId, restaurantId: restaurant.id },
        { $set: { status, updatedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      if (!result) {
        return NextResponse.json({ error: 'Pedido não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      notifyRestaurantClients(restaurant.id, { type: 'order_updated', order: result });
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // Delete order
    if (path.match(/^\/admin\/orders\/[\w-]+$/) && method === 'DELETE') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const orderId = pathSegments[2];
      const result = await db.collection('orders').deleteOne({ 
        id: orderId, 
        restaurantId: restaurant.id 
      });
      
      if (result.deletedCount === 0) {
        return NextResponse.json({ error: 'Pedido não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      notifyRestaurantClients(restaurant.id, { type: 'order_deleted', orderId });
      
      return NextResponse.json({ success: true }, { headers: corsHeaders });
    }

    // ==================== ADMIN CRUD - Categories ====================
    
    // Get categories
    if (path === '/admin/categories' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const categories = await db.collection('categories')
        .find({ restaurantId: restaurant.id })
        .sort({ order: 1 })
        .toArray();
      
      return NextResponse.json(categories, { headers: corsHeaders });
    }

    // Create category
    if (path === '/admin/categories' && method === 'POST') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const body = await request.json();
      const { name, icon } = body;
      
      const lastCategory = await db.collection('categories')
        .findOne({ restaurantId: restaurant.id }, { sort: { order: -1 } });
      
      const category = {
        id: uuidv4(),
        restaurantId: restaurant.id,
        name,
        icon: icon || '📦',
        order: (lastCategory?.order || 0) + 1,
        createdAt: new Date().toISOString()
      };
      
      await db.collection('categories').insertOne(category);
      
      return NextResponse.json(category, { status: 201, headers: corsHeaders });
    }

    // Update category
    if (path.match(/^\/admin\/categories\/[\w-]+$/) && method === 'PUT') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const categoryId = pathSegments[2];
      const body = await request.json();
      
      const result = await db.collection('categories').findOneAndUpdate(
        { id: categoryId, restaurantId: restaurant.id },
        { $set: { ...body, updatedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      if (!result) {
        return NextResponse.json({ error: 'Categoria não encontrada' }, { status: 404, headers: corsHeaders });
      }
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // Delete category
    if (path.match(/^\/admin\/categories\/[\w-]+$/) && method === 'DELETE') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const categoryId = pathSegments[2];
      
      // Check if category has products
      const productsCount = await db.collection('products').countDocuments({ 
        categoryId, 
        restaurantId: restaurant.id 
      });
      
      if (productsCount > 0) {
        return NextResponse.json({ 
          error: 'Não é possível excluir categoria com produtos' 
        }, { status: 400, headers: corsHeaders });
      }
      
      await db.collection('categories').deleteOne({ 
        id: categoryId, 
        restaurantId: restaurant.id 
      });
      
      return NextResponse.json({ success: true }, { headers: corsHeaders });
    }

    // ==================== ADMIN CRUD - Products ====================
    
    // Get products
    if (path === '/admin/products' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const products = await db.collection('products')
        .find({ restaurantId: restaurant.id })
        .toArray();
      
      return NextResponse.json(products, { headers: corsHeaders });
    }

    // Create product
    if (path === '/admin/products' && method === 'POST') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const body = await request.json();
      const { categoryId, name, description, price, image, tags } = body;
      
      const product = {
        id: uuidv4(),
        restaurantId: restaurant.id,
        categoryId,
        name,
        description: description || '',
        price: parseFloat(price),
        image: image || '',
        tags: tags || [],
        available: true,
        createdAt: new Date().toISOString()
      };
      
      await db.collection('products').insertOne(product);
      
      return NextResponse.json(product, { status: 201, headers: corsHeaders });
    }

    // Update product
    if (path.match(/^\/admin\/products\/[\w-]+$/) && method === 'PUT') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const productId = pathSegments[2];
      const body = await request.json();
      
      if (body.price) body.price = parseFloat(body.price);
      
      const result = await db.collection('products').findOneAndUpdate(
        { id: productId, restaurantId: restaurant.id },
        { $set: { ...body, updatedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      if (!result) {
        return NextResponse.json({ error: 'Produto não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // Toggle product availability
    if (path.match(/^\/admin\/products\/[\w-]+\/toggle$/) && method === 'PATCH') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const productId = pathSegments[2];
      const product = await db.collection('products').findOne({ 
        id: productId, 
        restaurantId: restaurant.id 
      });
      
      if (!product) {
        return NextResponse.json({ error: 'Produto não encontrado' }, { status: 404, headers: corsHeaders });
      }
      
      const result = await db.collection('products').findOneAndUpdate(
        { id: productId },
        { $set: { available: !product.available, updatedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // Delete product
    if (path.match(/^\/admin\/products\/[\w-]+$/) && method === 'DELETE') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const productId = pathSegments[2];
      await db.collection('products').deleteOne({ 
        id: productId, 
        restaurantId: restaurant.id 
      });
      
      return NextResponse.json({ success: true }, { headers: corsHeaders });
    }

    // ==================== ADMIN - Tables ====================
    
    // Get tables
    if (path === '/admin/tables' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const tables = await db.collection('tables')
        .find({ restaurantId: restaurant.id })
        .sort({ number: 1 })
        .toArray();
      
      return NextResponse.json(tables, { headers: corsHeaders });
    }

    // Create table
    if (path === '/admin/tables' && method === 'POST') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const body = await request.json();
      const { number } = body;
      
      const existing = await db.collection('tables').findOne({ 
        restaurantId: restaurant.id, 
        number 
      });
      
      if (existing) {
        return NextResponse.json({ error: 'Mesa já existe' }, { status: 400, headers: corsHeaders });
      }
      
      const table = {
        id: uuidv4(),
        restaurantId: restaurant.id,
        number,
        status: 'available',
        createdAt: new Date().toISOString()
      };
      
      await db.collection('tables').insertOne(table);
      
      return NextResponse.json(table, { status: 201, headers: corsHeaders });
    }

    // Delete table
    if (path.match(/^\/admin\/tables\/[\w-]+$/) && method === 'DELETE') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const tableId = pathSegments[2];
      await db.collection('tables').deleteOne({ 
        id: tableId, 
        restaurantId: restaurant.id 
      });
      
      return NextResponse.json({ success: true }, { headers: corsHeaders });
    }

    // Update restaurant settings
    if (path === '/admin/restaurant' && method === 'PUT') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const body = await request.json();
      const { name, description, logo, colorTheme } = body;
      
      const result = await db.collection('restaurants').findOneAndUpdate(
        { id: restaurant.id },
        { $set: { name, description, logo, colorTheme, updatedAt: new Date().toISOString() } },
        { returnDocument: 'after' }
      );
      
      return NextResponse.json(result, { headers: corsHeaders });
    }

    // ==================== STRIPE / SUBSCRIPTION ROUTES ====================

    // Get available plans
    if (path === '/plans' && method === 'GET') {
      const plansArray = Object.values(PLANS).map(plan => ({
        id: plan.id,
        name: plan.name,
        description: plan.description,
        price: plan.price,
        features: plan.features,
        limits: plan.limits,
        popular: plan.popular || false
      }));
      return NextResponse.json(plansArray, { headers: corsHeaders });
    }

    // NEW: Checkout with Registration (payment first, then account creation)
    if (path === '/stripe/checkout-with-registration' && method === 'POST') {
      const body = await request.json();
      const { planId, restaurantName, name, email, password } = body;

      // Validate
      if (!planId || !PLANS[planId]) {
        return NextResponse.json({ error: 'Plano inválido' }, { status: 400, headers: corsHeaders });
      }
      if (!restaurantName || !name || !email || !password) {
        return NextResponse.json({ error: 'Todos os campos são obrigatórios' }, { status: 400, headers: corsHeaders });
      }
      if (password.length < 6) {
        return NextResponse.json({ error: 'Senha deve ter pelo menos 6 caracteres' }, { status: 400, headers: corsHeaders });
      }

      // Check if email already exists
      const existingUser = await db.collection('users').findOne({ email: email.toLowerCase() });
      if (existingUser) {
        return NextResponse.json({ error: 'Este email já está cadastrado. Faça login.' }, { status: 400, headers: corsHeaders });
      }

      try {
        // Create pending registration record
        const pendingId = uuidv4();
        await db.collection('pending_registrations').insertOne({
          id: pendingId,
          restaurantName,
          name,
          email: email.toLowerCase(),
          password, // Will be hashed when account is created
          planId,
          status: 'pending',
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24h expiry
        });

        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
        
        const session = await createCheckoutSession({
          customerId: null,
          restaurantId: pendingId, // Use pendingId temporarily
          planId,
          customerEmail: email,
          successUrl: `${baseUrl}/assinatura/sucesso?session_id={CHECKOUT_SESSION_ID}&pending=${pendingId}`,
          cancelUrl: `${baseUrl}/assinatura/cancelado`
        });

        return NextResponse.json({ 
          url: session.url,
          sessionId: session.id 
        }, { headers: corsHeaders });
      } catch (error) {
        console.error('Checkout with Registration Error:', error);
        return NextResponse.json({ error: 'Erro ao processar', details: error.message }, { status: 500, headers: corsHeaders });
      }
    }

    // Create Stripe Checkout Session (for existing users)
    if (path === '/stripe/create-checkout-session' && method === 'POST') {
      const authHeader = request.headers.get('Authorization');
      const token = authHeader?.replace('Bearer ', '');
      if (!token) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }
      
      const payload = verifyToken(token);
      if (!payload) {
        return NextResponse.json({ error: 'Token inválido' }, { status: 401, headers: corsHeaders });
      }

      const restaurant = await db.collection('restaurants').findOne({ id: payload.restaurantId });
      if (!restaurant) {
        return NextResponse.json({ error: 'Restaurante não encontrado' }, { status: 404, headers: corsHeaders });
      }

      // Get user email
      const user = await db.collection('users').findOne({ id: payload.userId });
      
      const body = await request.json();
      const { planId } = body;

      if (!planId || !PLANS[planId]) {
        return NextResponse.json({ error: 'Plano inválido' }, { status: 400, headers: corsHeaders });
      }

      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
        
        const session = await createCheckoutSession({
          customerId: restaurant.stripeCustomerId || null,
          restaurantId: restaurant.id,
          planId,
          customerEmail: user?.email || null,
          successUrl: `${baseUrl}/assinatura/sucesso?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${baseUrl}/assinatura/cancelado`
        });

        return NextResponse.json({ 
          url: session.url,
          sessionId: session.id 
        }, { headers: corsHeaders });
      } catch (error) {
        console.error('Stripe Checkout Error:', error);
        return NextResponse.json({ error: 'Erro ao criar sessão de pagamento', details: error.message }, { status: 500, headers: corsHeaders });
      }
    }

    // Verify subscription after checkout
    if (path === '/subscription/verify' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }

      const sessionId = url.searchParams.get('session_id');
      
      if (!sessionId) {
        return NextResponse.json({ error: 'Session ID required' }, { status: 400, headers: corsHeaders });
      }

      try {
        const session = await stripe.checkout.sessions.retrieve(sessionId);
        
        return NextResponse.json({
          status: session.status,
          plan: session.metadata?.planId || restaurant.subscriptionPlan,
          customerId: session.customer
        }, { headers: corsHeaders });
      } catch (error) {
        return NextResponse.json({ error: 'Sessão não encontrada' }, { status: 404, headers: corsHeaders });
      }
    }

    // Get subscription completion data (for success page)
    if (path === '/subscription/complete' && method === 'GET') {
      const pendingId = url.searchParams.get('pending');
      
      if (pendingId) {
        const pending = await db.collection('pending_registrations').findOne({ id: pendingId });
        
        if (pending) {
          return NextResponse.json({
            email: pending.email,
            restaurantName: pending.restaurantName,
            name: pending.name,
            status: pending.status
          }, { headers: corsHeaders });
        }
      }
      
      return NextResponse.json({ status: 'not_found' }, { headers: corsHeaders });
    }

    // Get subscription status
    if (path === '/subscription/status' && method === 'GET') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }

      const plan = PLANS[restaurant.subscriptionPlan] || null;
      
      return NextResponse.json({
        active: restaurant.subscriptionActive || false,
        plan: restaurant.subscriptionPlan || 'none',
        planDetails: plan,
        expiresAt: restaurant.subscriptionExpiresAt || null,
        stripeCustomerId: restaurant.stripeCustomerId || null,
        stripeSubscriptionId: restaurant.stripeSubscriptionId || null
      }, { headers: corsHeaders });
    }

    // Create Stripe Portal Session (manage subscription)
    if (path === '/stripe/portal' && method === 'POST') {
      const restaurant = await getAuthRestaurant();
      if (!restaurant) {
        return NextResponse.json({ error: 'Não autorizado' }, { status: 401, headers: corsHeaders });
      }

      if (!restaurant.stripeCustomerId) {
        return NextResponse.json({ error: 'Nenhuma assinatura encontrada' }, { status: 400, headers: corsHeaders });
      }

      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
        const session = await createPortalSession(
          restaurant.stripeCustomerId,
          `${baseUrl}/admin/dashboard`
        );

        return NextResponse.json({ url: session.url }, { headers: corsHeaders });
      } catch (error) {
        console.error('Stripe Portal Error:', error);
        return NextResponse.json({ error: 'Erro ao criar portal' }, { status: 500, headers: corsHeaders });
      }
    }

    // Stripe Webhook
    if (path === '/stripe/webhook' && method === 'POST') {
      const body = await request.text();
      const sig = request.headers.get('stripe-signature');
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      let event;

      try {
        if (webhookSecret) {
          event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
        } else {
          // For development without webhook secret
          event = JSON.parse(body);
        }
      } catch (err) {
        console.error('Webhook signature verification failed:', err.message);
        return NextResponse.json({ error: 'Webhook Error' }, { status: 400, headers: corsHeaders });
      }

      // Handle the event
      switch (event.type) {
        case 'checkout.session.completed': {
          const session = event.data.object;
          const { restaurantId, planId } = session.metadata || {};
          
          if (restaurantId) {
            const plan = PLANS[planId] || PLANS.gourmet;
            
            // Check if this is a new registration (pending) or existing restaurant
            const pendingRegistration = await db.collection('pending_registrations').findOne({ id: restaurantId });
            
            if (pendingRegistration) {
              // NEW REGISTRATION - Create restaurant and user from pending data
              const { hashPassword } = await import('@/lib/auth');
              const newRestaurantId = uuidv4();
              const userId = uuidv4();
              const slug = pendingRegistration.restaurantName
                .toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');

              // Create restaurant
              const restaurant = {
                id: newRestaurantId,
                slug: `${slug}-${newRestaurantId.substring(0, 6)}`,
                name: pendingRegistration.restaurantName,
                description: '',
                logo: '',
                colorTheme: { primary: '#10b981', secondary: '#14b8a6' },
                settings: { currency: 'MZN', timezone: 'Africa/Maputo' },
                ownerId: userId,
                stripeCustomerId: session.customer,
                stripeSubscriptionId: session.subscription,
                subscriptionPlan: planId,
                subscriptionStatus: 'active',
                subscriptionActive: true,
                subscriptionLimits: plan.limits,
                subscriptionExpiresAt: null,
                trialEndsAt: null,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              };

              // Create user
              const user = {
                id: userId,
                email: pendingRegistration.email,
                passwordHash: hashPassword(pendingRegistration.password),
                name: pendingRegistration.name,
                restaurantId: newRestaurantId,
                role: 'owner',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              };

              // Create default tables
              const tables = Array.from({ length: 10 }, (_, i) => ({
                id: uuidv4(),
                restaurantId: newRestaurantId,
                number: i + 1,
                status: 'available',
                createdAt: new Date().toISOString()
              }));

              await db.collection('restaurants').insertOne(restaurant);
              await db.collection('users').insertOne(user);
              await db.collection('tables').insertMany(tables);

              // Update pending registration with actual restaurant ID
              await db.collection('pending_registrations').updateOne(
                { id: restaurantId },
                { 
                  $set: { 
                    status: 'completed', 
                    actualRestaurantId: newRestaurantId,
                    completedAt: new Date().toISOString() 
                  } 
                }
              );

              console.log(`NEW ACCOUNT CREATED: ${pendingRegistration.email} - Restaurant: ${restaurant.name} - Plan: ${planId}`);
            } else {
              // EXISTING RESTAURANT - Just update subscription
              await db.collection('restaurants').updateOne(
                { id: restaurantId },
                {
                  $set: {
                    stripeCustomerId: session.customer,
                    stripeSubscriptionId: session.subscription,
                    subscriptionPlan: planId,
                    subscriptionActive: true,
                    subscriptionStatus: 'active',
                    subscriptionLimits: plan.limits,
                    subscriptionExpiresAt: null,
                    updatedAt: new Date().toISOString()
                  }
                }
              );
              console.log(`Subscription activated for existing restaurant ${restaurantId} - Plan: ${planId}`);
            }
          }
          break;
        }

        case 'customer.subscription.updated': {
          const subscription = event.data.object;
          const { restaurantId, planId } = subscription.metadata || {};
          
          if (restaurantId) {
            const plan = PLANS[planId] || PLANS.starter;
            const isActive = ['active', 'trialing'].includes(subscription.status);
            
            await db.collection('restaurants').updateOne(
              { id: restaurantId },
              {
                $set: {
                  subscriptionStatus: subscription.status,
                  subscriptionActive: isActive,
                  subscriptionPlan: planId,
                  subscriptionLimits: plan.limits,
                  subscriptionExpiresAt: subscription.cancel_at ? new Date(subscription.cancel_at * 1000).toISOString() : null,
                  updatedAt: new Date().toISOString()
                }
              }
            );
          }
          break;
        }

        case 'customer.subscription.deleted': {
          const subscription = event.data.object;
          const { restaurantId } = subscription.metadata || {};
          
          if (restaurantId) {
            await db.collection('restaurants').updateOne(
              { id: restaurantId },
              {
                $set: {
                  subscriptionActive: false,
                  subscriptionStatus: 'canceled',
                  subscriptionExpiresAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                }
              }
            );
            console.log(`Subscription canceled for restaurant ${restaurantId}`);
          }
          break;
        }

        case 'invoice.payment_failed': {
          const invoice = event.data.object;
          const customerId = invoice.customer;
          
          // Find restaurant by customer ID
          const restaurant = await db.collection('restaurants').findOne({ stripeCustomerId: customerId });
          if (restaurant) {
            await db.collection('restaurants').updateOne(
              { id: restaurant.id },
              {
                $set: {
                  subscriptionStatus: 'past_due',
                  updatedAt: new Date().toISOString()
                }
              }
            );
            console.log(`Payment failed for restaurant ${restaurant.id}`);
          }
          break;
        }

        default:
          console.log(`Unhandled event type: ${event.type}`);
      }

      return NextResponse.json({ received: true }, { headers: corsHeaders });
    }

    // 404 for unknown routes
    return NextResponse.json({ error: 'Rota não encontrada', path }, { status: 404, headers: corsHeaders });

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor', details: error.message },
      { status: 500, headers: corsHeaders }
    );
  }
}

export async function GET(request, context) {
  return handleRequest(request, context);
}

export async function POST(request, context) {
  return handleRequest(request, context);
}

export async function PUT(request, context) {
  return handleRequest(request, context);
}

export async function PATCH(request, context) {
  return handleRequest(request, context);
}

export async function DELETE(request, context) {
  return handleRequest(request, context);
}

export async function OPTIONS(request, context) {
  return handleRequest(request, context);
}
