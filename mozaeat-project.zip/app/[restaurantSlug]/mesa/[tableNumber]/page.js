'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
  ShoppingCart, Plus, Minus, Trash2, Send, 
  ChevronLeft, Clock, CheckCircle2, Loader2,
  Leaf, Wheat, Star, Filter, X, Receipt,
  Bell, CreditCard, Banknote, Smartphone, UtensilsCrossed
} from 'lucide-react';

const TAG_CONFIG = {
  vegano: { label: 'Vegano', icon: Leaf, color: 'bg-green-100 text-green-700' },
  sem_gluten: { label: 'Sem Glúten', icon: Wheat, color: 'bg-amber-100 text-amber-700' },
  destaque: { label: 'Destaque', icon: Star, color: 'bg-teal-100 text-teal-700' }
};

const STATUS_LABELS = {
  new: { label: 'Na fila', color: 'bg-emerald-100 text-emerald-700' },
  preparing: { label: 'Preparando', color: 'bg-yellow-100 text-yellow-700' },
  ready: { label: 'Pronto', color: 'bg-green-100 text-green-700' },
  delivered: { label: 'Entregue', color: 'bg-gray-100 text-gray-500' }
};

export default function MenuPage() {
  const params = useParams();
  const router = useRouter();
  const { restaurantSlug, tableNumber } = params;

  const [restaurant, setRestaurant] = useState(null);
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [activeCategory, setActiveCategory] = useState(null);
  const [activeFilter, setActiveFilter] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [showComanda, setShowComanda] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [comanda, setComanda] = useState({ orders: [], total: 0 });
  const [callingWaiter, setCallingWaiter] = useState(false);

  useEffect(() => {
    fetchData();
  }, [restaurantSlug, tableNumber]);

  const fetchData = async () => {
    try {
      const tableRes = await fetch(`/api/r/${restaurantSlug}/mesa/${tableNumber}`);
      if (!tableRes.ok) {
        toast.error('Mesa não encontrada');
        router.push('/');
        return;
      }

      const menuRes = await fetch(`/api/r/${restaurantSlug}/menu`);
      if (!menuRes.ok) {
        toast.error('Restaurante não encontrado');
        router.push('/');
        return;
      }

      const { restaurant: restData, menu: menuData } = await menuRes.json();
      setRestaurant(restData);
      const nonEmptyMenu = menuData.filter(cat => cat.products && cat.products.length > 0);
      setMenu(nonEmptyMenu);
      if (nonEmptyMenu.length > 0) {
        setActiveCategory(nonEmptyMenu[0].id);
      }
      
      // Fetch comanda
      fetchComanda();
    } catch (error) {
      toast.error('Erro ao carregar');
      router.push('/');
    } finally {
      setLoading(false);
    }
  };

  const fetchComanda = async () => {
    try {
      const res = await fetch(`/api/r/${restaurantSlug}/mesa/${tableNumber}/orders`);
      if (res.ok) {
        const data = await res.json();
        setComanda(data);
      }
    } catch (e) {}
  };

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { productId: product.id, name: product.name, price: product.price, quantity: 1 }];
    });
    toast.success(`${product.name} adicionado!`, { duration: 1000 });
  };

  const updateQuantity = (productId, delta) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : null;
      }
      return item;
    }).filter(Boolean));
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const filteredMenu = useMemo(() => {
    if (!activeFilter) return menu;
    return menu.map(cat => ({
      ...cat,
      products: cat.products.filter(p => p.tags?.includes(activeFilter))
    })).filter(cat => cat.products.length > 0);
  }, [menu, activeFilter]);

  const sendOrder = async () => {
    if (cart.length === 0) { toast.error('Adicione itens'); return; }
    setSending(true);
    try {
      const response = await fetch(`/api/r/${restaurantSlug}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tableNumber: parseInt(tableNumber),
          items: cart.map(item => ({ productId: item.productId, quantity: item.quantity }))
        })
      });
      if (!response.ok) throw new Error();
      setCart([]);
      setShowCart(false);
      toast.success('Pedido enviado!');
      fetchComanda(); // Refresh comanda
    } catch { toast.error('Erro ao enviar'); }
    finally { setSending(false); }
  };

  const callWaiter = async (type, paymentMethod = null) => {
    setCallingWaiter(true);
    try {
      const response = await fetch(`/api/r/${restaurantSlug}/mesa/${tableNumber}/call`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, paymentMethod })
      });
      if (!response.ok) throw new Error();
      toast.success(type === 'waiter' ? 'Empregado chamado!' : 'Conta solicitada!');
      setShowCallModal(false);
    } catch { toast.error('Erro ao chamar'); }
    finally { setCallingWaiter(false); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-500" />
      </div>
    );
  }

  const primaryColor = restaurant?.colorTheme?.primary || '#10b981'; // emerald-500
  const secondaryColor = restaurant?.colorTheme?.secondary || '#14b8a6'; // teal-500

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Header */}
      <header className="text-white sticky top-0 z-40" style={{ background: `linear-gradient(135deg, ${primaryColor}, ${secondaryColor})` }}>
        <div className="px-3 py-3">
          <div className="flex items-center justify-between">
            <button onClick={() => router.push('/')} className="p-1 -ml-1 opacity-80 hover:opacity-100">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1.5">
                <span className="text-lg">{restaurant?.logo}</span>
                <span className="font-bold text-sm">{restaurant?.name}</span>
              </div>
              <p className="text-[10px] opacity-80">Mesa {tableNumber}</p>
            </div>
            {/* Comanda Button */}
            <button 
              onClick={() => { fetchComanda(); setShowComanda(true); }}
              className="relative p-1.5 bg-white/20 rounded-lg"
            >
              <Receipt className="w-5 h-5" />
              {comanda.orders.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center">
                  {comanda.orders.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className="bg-white border-b px-3 py-2">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveFilter(null)}
            className={`px-2.5 py-1 rounded-full text-xs whitespace-nowrap flex items-center gap-1 transition-all
              ${!activeFilter ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600'}`}
          >
            <Filter className="w-3 h-3" /> Todos
          </button>
          {Object.entries(TAG_CONFIG).map(([key, config]) => (
            <button
              key={key}
              onClick={() => setActiveFilter(activeFilter === key ? null : key)}
              className={`px-2.5 py-1 rounded-full text-xs whitespace-nowrap flex items-center gap-1 transition-all
                ${activeFilter === key ? config.color : 'bg-gray-100 text-gray-600'}`}
            >
              <config.icon className="w-3 h-3" /> {config.label}
            </button>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white border-b sticky top-[52px] z-30">
        <div className="flex gap-1.5 p-2 overflow-x-auto no-scrollbar">
          {filteredMenu.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-full whitespace-nowrap text-xs font-medium transition-all
                ${activeCategory === cat.id ? 'text-white' : 'bg-gray-100 text-gray-600'}`}
              style={activeCategory === cat.id ? { backgroundColor: primaryColor } : {}}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Products */}
      <main className="p-3">
        {filteredMenu.filter(cat => cat.id === activeCategory).map((category) => (
          <div key={category.id}>
            <h2 className="text-base font-bold text-gray-900 mb-3">
              {category.icon} {category.name}
            </h2>
            <div className="space-y-2">
              {category.products.map((product) => (
                <Card key={product.id} className="overflow-hidden">
                  <div className="flex">
                    <div className="w-24 h-24 flex-shrink-0">
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    </div>
                    <CardContent className="flex-1 p-2.5 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h3 className="font-semibold text-sm leading-tight">{product.name}</h3>
                          {product.tags?.includes('destaque') && <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 flex-shrink-0" />}
                        </div>
                        <p className="text-[10px] text-gray-500 line-clamp-2 mt-0.5">{product.description}</p>
                        <div className="flex gap-1 mt-1">
                          {product.tags?.filter(t => t !== 'destaque').map(tag => (
                            <span key={tag} className={`text-[9px] px-1 py-0.5 rounded ${TAG_CONFIG[tag]?.color || 'bg-gray-100'}`}>
                              {TAG_CONFIG[tag]?.label || tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-base font-bold" style={{ color: primaryColor }}>
                          MZN {product.price.toFixed(2)}
                        </span>
                        <Button size="sm" onClick={() => addToCart(product)} className="h-8 w-8 p-0" style={{ backgroundColor: primaryColor }}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </main>

      {/* Bottom Actions Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50 safe-area-pb">
        <div className="grid grid-cols-3 gap-2 p-3">
          {/* Chamar Empregado */}
          <Button
            variant="outline"
            onClick={() => setShowCallModal(true)}
            className="flex-col h-auto py-2 text-xs"
          >
            <Bell className="w-5 h-5 mb-1" />
            Chamar
          </Button>
          
          {/* Ver Carrinho */}
          <Button
            onClick={() => setShowCart(true)}
            disabled={cartCount === 0}
            className="flex-col h-auto py-2 text-xs relative"
            style={{ backgroundColor: cartCount > 0 ? primaryColor : undefined }}
          >
            <ShoppingCart className="w-5 h-5 mb-1" />
            Pedir {cartCount > 0 && `(${cartCount})`}
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Button>
          
          {/* Ver Comanda */}
          <Button
            variant="outline"
            onClick={() => { fetchComanda(); setShowComanda(true); }}
            className="flex-col h-auto py-2 text-xs"
          >
            <Receipt className="w-5 h-5 mb-1" />
            Conta
          </Button>
        </div>
      </div>

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-2xl max-h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-200">
            <div className="p-3 border-b flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-lg font-bold">Novo Pedido</h2>
              <button onClick={() => setShowCart(false)} className="p-1"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="flex-1 overflow-auto p-3">
              {cart.map((item) => (
                <div key={item.productId} className="flex items-center gap-2 mb-3 pb-3 border-b">
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{item.name}</h3>
                    <p className="text-xs text-gray-500">MZN {item.price.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQuantity(item.productId, -1)}>
                      <Minus className="w-3 h-3" />
                    </Button>
                    <span className="w-6 text-center text-sm font-bold">{item.quantity}</span>
                    <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQuantity(item.productId, 1)}>
                      <Plus className="w-3 h-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-red-500" onClick={() => removeFromCart(item.productId)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 border-t bg-gray-50">
              <div className="flex justify-between items-center mb-3">
                <span className="text-gray-600">Total deste pedido</span>
                <span className="text-xl font-bold" style={{ color: primaryColor }}>MZN {cartTotal.toFixed(2)}</span>
              </div>
              <Button onClick={sendOrder} disabled={sending} className="w-full h-12 text-base bg-gradient-to-r from-green-500 to-emerald-500">
                {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Send className="w-5 h-5 mr-2" /> Enviar Pedido</>}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Comanda Modal */}
      {showComanda && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-2xl max-h-[90vh] flex flex-col animate-in slide-in-from-bottom duration-200">
            <div className="p-3 border-b flex items-center justify-between sticky top-0 bg-white z-10">
              <div>
                <h2 className="text-lg font-bold">Minha Conta</h2>
                <p className="text-xs text-gray-500">Mesa {tableNumber}</p>
              </div>
              <button onClick={() => setShowComanda(false)} className="p-1"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="flex-1 overflow-auto p-3">
              {comanda.orders.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Receipt className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p>Nenhum pedido ainda</p>
                </div>
              ) : (
                comanda.orders.map((order, idx) => (
                  <div key={order.id} className="mb-4 pb-4 border-b last:border-0">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-400">
                        Pedido #{idx + 1} • {new Date(order.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <Badge className={STATUS_LABELS[order.status]?.color || 'bg-gray-100'}>
                        {STATUS_LABELS[order.status]?.label || order.status}
                      </Badge>
                    </div>
                    {order.items.map((item, i) => (
                      <div key={i} className="flex justify-between text-sm mb-1">
                        <span>{item.quantity}x {item.name}</span>
                        <span className="text-gray-600">MZN {item.subtotal.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                ))
              )}
            </div>

            {comanda.orders.length > 0 && (
              <div className="p-3 border-t bg-gray-50">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium">Total da Mesa</span>
                  <span className="text-2xl font-bold" style={{ color: primaryColor }}>MZN {comanda.total.toFixed(2)}</span>
                </div>
                <Button 
                  onClick={() => { setShowComanda(false); setShowCallModal(true); }}
                  className="w-full h-12"
                  style={{ backgroundColor: primaryColor }}
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Pedir a Conta
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Call Waiter / Bill Modal */}
      {showCallModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-2xl animate-in slide-in-from-bottom duration-200">
            <div className="p-3 border-b flex items-center justify-between">
              <h2 className="text-lg font-bold">Como podemos ajudar?</h2>
              <button onClick={() => setShowCallModal(false)} className="p-1"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="p-4 space-y-3">
              {/* Call Waiter */}
              <Button
                variant="outline"
                onClick={() => callWaiter('waiter')}
                disabled={callingWaiter}
                className="w-full h-14 justify-start text-left"
              >
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mr-3">
                  <Bell className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Chamar Empregado</p>
                  <p className="text-xs text-gray-500">Solicitar assistência</p>
                </div>
              </Button>

              <Separator />
              <p className="text-sm text-gray-500 text-center">Ou pedir a conta:</p>

              {/* Payment Options */}
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant="outline"
                  onClick={() => callWaiter('bill', 'card')}
                  disabled={callingWaiter}
                  className="flex-col h-auto py-3"
                >
                  <CreditCard className="w-6 h-6 mb-1 text-teal-600" />
                  <span className="text-xs">Cartão</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => callWaiter('bill', 'cash')}
                  disabled={callingWaiter}
                  className="flex-col h-auto py-3"
                >
                  <Banknote className="w-6 h-6 mb-1 text-green-600" />
                  <span className="text-xs">Dinheiro</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => callWaiter('bill', 'pix')}
                  disabled={callingWaiter}
                  className="flex-col h-auto py-3"
                >
                  <Smartphone className="w-6 h-6 mb-1 text-teal-600" />
                  <span className="text-xs">Pix</span>
                </Button>
              </div>

              {comanda.total > 0 && (
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <p className="text-sm text-gray-500">Total a pagar</p>
                  <p className="text-2xl font-bold" style={{ color: primaryColor }}>MZN {comanda.total.toFixed(2)}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .safe-area-pb { padding-bottom: max(12px, env(safe-area-inset-bottom)); }
      `}</style>
    </div>
  );
}
