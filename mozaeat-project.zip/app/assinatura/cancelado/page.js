'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { XCircle, ArrowLeft, RefreshCw, Utensils } from 'lucide-react';

export default function SubscriptionCanceledPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      {/* Logo */}
      <div className="fixed top-4 left-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <Utensils className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-gray-900">MozaEat</span>
        </Link>
      </div>

      <Card className="w-full max-w-md text-center shadow-xl">
        <CardContent className="pt-8 pb-6">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-10 h-10 text-red-500" />
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Pagamento Cancelado</h1>
          <p className="text-gray-600 mb-6">
            O processo de pagamento foi cancelado. Nenhuma cobrança foi realizada.
          </p>

          <div className="space-y-3">
            <Link href="/planos" className="block">
              <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Tentar Novamente
              </Button>
            </Link>
            <Link href="/" className="block">
              <Button variant="outline" className="w-full rounded-full">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Início
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
