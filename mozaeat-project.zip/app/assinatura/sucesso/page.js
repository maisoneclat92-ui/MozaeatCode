'use client';

import { useEffect, useState, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Loader2, ArrowRight, Mail, Lock, Copy, Utensils } from 'lucide-react';
import { toast } from 'sonner';

function SuccessContent() {
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    const pendingId = searchParams.get('pending');
    
    if (sessionId || pendingId) {
      // Fetch registration info
      fetch(`/api/subscription/complete?session_id=${sessionId || ''}&pending=${pendingId || ''}`)
        .then(res => res.json())
        .then(result => {
          setData(result);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [searchParams]);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copiado!');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-emerald-500 mx-auto mb-4" />
          <p className="text-gray-600">Processando seu pagamento...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center p-4">
      {/* Logo */}
      <div className="fixed top-4 left-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <Utensils className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-gray-900">MozaEat</span>
        </Link>
      </div>

      <Card className="w-full max-w-md shadow-xl border-emerald-200">
        <CardContent className="pt-8 pb-6">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-emerald-500" />
            </div>
            
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Pagamento Confirmado!</h1>
            <p className="text-gray-600">
              Sua assinatura foi ativada com sucesso.
            </p>
          </div>

          {data?.email && (
            <div className="bg-gray-50 rounded-xl p-4 mb-6 space-y-3">
              <h3 className="font-semibold text-center mb-3">Suas Credenciais de Acesso</h3>
              
              <div className="flex items-center justify-between bg-white rounded-lg p-3 border">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-mono">{data.email}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={() => copyToClipboard(data.email)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex items-center justify-between bg-white rounded-lg p-3 border">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">Senha que você definiu no cadastro</span>
                </div>
              </div>

              <p className="text-xs text-center text-gray-500 mt-2">
                Guarde suas credenciais em local seguro
              </p>
            </div>
          )}

          {data?.restaurantName && (
            <div className="bg-orange-50 rounded-lg p-3 mb-6 text-center">
              <p className="text-sm text-orange-700">
                <span className="font-medium">Restaurante:</span> {data.restaurantName}
              </p>
              <p className="text-sm text-orange-700">
                <span className="font-medium">Plano:</span> Gourmet
              </p>
            </div>
          )}

          <div className="space-y-3">
            <Link href="/admin" className="block">
              <Button className="w-full h-12 bg-gradient-to-r from-emerald-500 to-teal-600 text-lg rounded-full shadow-lg shadow-emerald-500/25">
                Fazer Login
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>

          <p className="text-xs text-center text-gray-500 mt-4">
            Você também receberá um email com essas informações
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SubscriptionSuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-green-500" />
      </div>
    }>
      <SuccessContent />
    </Suspense>
  );
}
