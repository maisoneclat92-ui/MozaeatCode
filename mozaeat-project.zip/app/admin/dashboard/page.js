'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { 
  ChefHat, Loader2, LogOut, QrCode, UtensilsCrossed, 
  Package, LayoutGrid, ExternalLink, ClipboardList,
  DollarSign, Menu, X, Home, Crown, AlertTriangle, CreditCard
} from 'lucide-react';

export default function AdminDashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [restaurant, setRestaurant] = useState(null);
  const [stats, setStats] = useState({ orders: 0, products: 0, tables: 0 });
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      router.push('/admin');
      return;
    }

    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => {
        if (!res.ok) throw new Error('Sessão expirada');
        return res.json();
      })
      .then(data => {
        setUser(data.user);
        setRestaurant(data.restaurant);
        localStorage.setItem('admin_restaurant', JSON.stringify(data.restaurant));
        fetchStats(token);
      })
      .catch(() => {
        localStorage.removeItem('admin_token');
        router.push('/admin');
      });
  }, [router]);

  const fetchStats = async (token) => {
    try {
      const [ordersRes, productsRes, tablesRes] = await Promise.all([
        fetch('/api/admin/orders', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/products', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/tables', { headers: { Authorization: `Bearer ${token}` } })
      ]);

      const [orders, products, tables] = await Promise.all([
        ordersRes.json(),
        productsRes.json(),
        tablesRes.json()
      ]);

      setStats({
        orders: orders.length,
        products: products.length,
        tables: tables.length,
        todayRevenue: orders
          .filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString())
          .reduce((sum, o) => sum + o.total, 0)
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_user');
    localStorage.removeItem('admin_restaurant');
    router.push('/admin');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const menuUrl = `${baseUrl}/${restaurant?.slug}/mesa/1`;

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                <UtensilsCrossed className="w-5 h-5 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className="font-bold text-lg leading-tight">{restaurant?.name}</h1>
                <p className="text-xs text-gray-500">/{restaurant?.slug}</p>
              </div>
              <div className="sm:hidden">
                <h1 className="font-bold text-sm leading-tight">{restaurant?.name}</h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600 hidden sm:block">Olá, {user?.name}</span>
              <Button variant="ghost" size="icon" onClick={() => setMenuOpen(!menuOpen)} className="md:hidden">
                {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={handleLogout} className="hidden md:flex">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden border-t bg-white px-4 py-3 space-y-2">
            <Link href="/admin/cozinha" onClick={() => setMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start">
                <ChefHat className="w-4 h-4 mr-2" /> Cozinha (KDS)
              </Button>
            </Link>
            <Link href="/admin/cardapio" onClick={() => setMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start">
                <Package className="w-4 h-4 mr-2" /> Cardápio
              </Button>
            </Link>
            <Link href="/admin/mesas" onClick={() => setMenuOpen(false)}>
              <Button variant="ghost" className="w-full justify-start">
                <QrCode className="w-4 h-4 mr-2" /> Mesas & QR
              </Button>
            </Link>
            <Button variant="ghost" className="w-full justify-start text-red-500" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" /> Sair
            </Button>
          </div>
        )}
      </header>

      <main className="p-4 max-w-6xl mx-auto">
        {/* Stats - Mobile Optimized */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Pedidos</p>
                  <p className="text-2xl font-bold">{stats.orders}</p>
                </div>
                <ClipboardList className="w-8 h-8 text-emerald-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Facturação</p>
                  <p className="text-xl font-bold">{(stats.todayRevenue || 0).toLocaleString()} MZN</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Produtos</p>
                  <p className="text-2xl font-bold">{stats.products}</p>
                </div>
                <Package className="w-8 h-8 text-blue-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Mesas</p>
                  <p className="text-2xl font-bold">{stats.tables}</p>
                </div>
                <LayoutGrid className="w-8 h-8 text-purple-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions - Mobile Optimized */}
        <h2 className="text-lg font-bold mb-3">Ações Rápidas</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          <Link href="/admin/cozinha">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-red-200 bg-gradient-to-br from-red-50 to-orange-50 h-full">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <ChefHat className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Painel da Cozinha</h3>
                    <p className="text-xs text-gray-500">KDS em tempo real</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/cardapio">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50 h-full">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Package className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Gerenciar Cardápio</h3>
                    <p className="text-xs text-gray-500">Produtos e categorias</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/mesas">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-purple-200 bg-gradient-to-br from-purple-50 to-violet-50 h-full">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <QrCode className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Mesas & QR Codes</h3>
                    <p className="text-xs text-gray-500">Gerar e imprimir</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Subscription Card */}
        <SubscriptionCard restaurant={restaurant} />

        {/* Menu Preview - Mobile Optimized */}
        <Card className="mt-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Link do seu Cardápio</CardTitle>
            <CardDescription className="text-xs">Compartilhe com seus clientes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Input 
                value={menuUrl} 
                readOnly 
                className="font-mono text-xs"
              />
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    navigator.clipboard.writeText(menuUrl);
                    toast.success('Link copiado!');
                  }}
                >
                  Copiar
                </Button>
                <Link href={`/${restaurant?.slug}/mesa/1`} target="_blank" className="flex-1">
                  <Button className="w-full">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Abrir
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t safe-area-pb">
        <div className="grid grid-cols-4 gap-1 p-2">
          <Link href="/admin/dashboard">
            <Button variant="ghost" className="w-full flex-col h-auto py-2 text-emerald-600">
              <Home className="w-5 h-5" />
              <span className="text-[10px] mt-1">Início</span>
            </Button>
          </Link>
          <Link href="/admin/cozinha">
            <Button variant="ghost" className="w-full flex-col h-auto py-2">
              <ChefHat className="w-5 h-5" />
              <span className="text-[10px] mt-1">Cozinha</span>
            </Button>
          </Link>
          <Link href="/admin/cardapio">
            <Button variant="ghost" className="w-full flex-col h-auto py-2">
              <Package className="w-5 h-5" />
              <span className="text-[10px] mt-1">Cardápio</span>
            </Button>
          </Link>
          <Link href="/admin/mesas">
            <Button variant="ghost" className="w-full flex-col h-auto py-2">
              <QrCode className="w-5 h-5" />
              <span className="text-[10px] mt-1">QR Codes</span>
            </Button>
          </Link>
        </div>
      </nav>

      {/* Spacer for bottom nav */}
      <div className="h-20 md:hidden" />
    </div>
  );
}

// Subscription Card Component
function SubscriptionCard({ restaurant }) {
  const [loading, setLoading] = useState(false);
  
  const plan = restaurant?.subscriptionPlan || 'trial';
  const status = restaurant?.subscriptionStatus || 'trialing';
  const trialEndsAt = restaurant?.trialEndsAt;
  
  const planNames = {
    gourmet: 'Plano Gourmet'
  };
  
  const planColors = {
    gourmet: 'from-emerald-500 to-teal-600'
  };
  
  const isActive = restaurant?.subscriptionActive;
  const needsSubscription = !isActive;

  const handleManageSubscription = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('admin_token');
      const response = await fetch('/api/stripe/portal', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        window.location.href = data.url;
      } else {
        // No subscription yet, redirect to plans
        window.location.href = '/planos';
      }
    } catch (error) {
      window.location.href = '/planos';
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className={`overflow-hidden ${needsSubscription ? 'border-amber-300' : 'border-green-300'}`}>
      <div className={`h-2 bg-gradient-to-r ${isActive ? planColors.gourmet : 'from-gray-400 to-gray-500'}`} />
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${isActive ? planColors.gourmet : 'from-gray-400 to-gray-500'} flex items-center justify-center`}>
              <Crown className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold">{isActive ? planNames.gourmet : 'Sem Assinatura'}</h3>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  isActive ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {isActive ? 'Ativo' : 'Pendente'}
                </span>
              </div>
              <p className="text-xs text-gray-500">
                {isActive 
                  ? 'Acesso completo a todas as funcionalidades' 
                  : 'Assine para ativar seu restaurante'}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            {needsSubscription ? (
              <Link href="/planos">
                <Button size="sm" className="bg-gradient-to-r from-emerald-500 to-teal-600">
                  <CreditCard className="w-4 h-4 mr-1" />
                  Assinar
                </Button>
              </Link>
            ) : (
              <Button 
                size="sm" 
                variant="outline"
                onClick={handleManageSubscription}
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Gerenciar'}
              </Button>
            )}
          </div>
        </div>
        
        {needsSubscription && (
          <div className="mt-3 p-3 rounded-lg flex items-start gap-2 bg-amber-50">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0 text-amber-500" />
            <p className="text-xs text-amber-700">
              Seu restaurante precisa de uma assinatura ativa para receber pedidos. Assine agora!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
