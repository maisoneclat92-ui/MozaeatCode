'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { 
  ArrowLeft, Plus, Pencil, Trash2, Loader2, Package,
  LayoutGrid, Save, X, DollarSign, Home, ChefHat, QrCode
} from 'lucide-react';

const TAGS = [
  { value: 'vegano', label: 'Vegano', color: 'bg-green-100 text-green-700' },
  { value: 'sem_gluten', label: 'Sem Glúten', color: 'bg-amber-100 text-amber-700' },
  { value: 'destaque', label: 'Destaque', color: 'bg-purple-100 text-purple-700' }
];

export default function CardapioPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [activeTab, setActiveTab] = useState('products');
  const [showModal, setShowModal] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);

  const [productForm, setProductForm] = useState({ name: '', description: '', price: '', image: '', categoryId: '', tags: [] });
  const [categoryForm, setCategoryForm] = useState({ name: '', icon: '' });

  const token = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;

  useEffect(() => {
    if (!token) { router.push('/admin'); return; }
    fetchData();
  }, [router, token]);

  const fetchData = async () => {
    try {
      const [catRes, prodRes] = await Promise.all([
        fetch('/api/admin/categories', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/products', { headers: { Authorization: `Bearer ${token}` } })
      ]);
      if (catRes.ok && prodRes.ok) {
        setCategories(await catRes.json());
        setProducts(await prodRes.json());
      }
    } catch (error) {
      toast.error('Erro ao carregar');
    } finally {
      setLoading(false);
    }
  };

  const openProductModal = (product = null) => {
    if (product) {
      setProductForm({ name: product.name, description: product.description || '', price: product.price.toString(), image: product.image || '', categoryId: product.categoryId, tags: product.tags || [] });
      setEditingItem(product);
    } else {
      setProductForm({ name: '', description: '', price: '', image: '', categoryId: categories[0]?.id || '', tags: [] });
      setEditingItem(null);
    }
    setShowModal('product');
  };

  const saveProduct = async () => {
    if (!productForm.name || !productForm.price || !productForm.categoryId) {
      toast.error('Preencha os campos obrigatórios'); return;
    }
    setSaving(true);
    try {
      const url = editingItem ? `/api/admin/products/${editingItem.id}` : '/api/admin/products';
      const method = editingItem ? 'PUT' : 'POST';
      const response = await fetch(url, {
        method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(productForm)
      });
      if (!response.ok) throw new Error();
      toast.success(editingItem ? 'Atualizado!' : 'Criado!');
      setShowModal(null);
      fetchData();
    } catch { toast.error('Erro ao salvar'); }
    finally { setSaving(false); }
  };

  const toggleAvailability = async (product) => {
    try {
      await fetch(`/api/admin/products/${product.id}/toggle`, { method: 'PATCH', headers: { Authorization: `Bearer ${token}` } });
      toast.success(product.available ? 'Desativado' : 'Ativado');
      fetchData();
    } catch { toast.error('Erro'); }
  };

  const deleteProduct = async (product) => {
    if (!confirm(`Excluir "${product.name}"?`)) return;
    try {
      await fetch(`/api/admin/products/${product.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      toast.success('Excluído'); fetchData();
    } catch { toast.error('Erro'); }
  };

  const openCategoryModal = (category = null) => {
    if (category) {
      setCategoryForm({ name: category.name, icon: category.icon || '' });
      setEditingItem(category);
    } else {
      setCategoryForm({ name: '', icon: '📦' });
      setEditingItem(null);
    }
    setShowModal('category');
  };

  const saveCategory = async () => {
    if (!categoryForm.name) { toast.error('Preencha o nome'); return; }
    setSaving(true);
    try {
      const url = editingItem ? `/api/admin/categories/${editingItem.id}` : '/api/admin/categories';
      const method = editingItem ? 'PUT' : 'POST';
      await fetch(url, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify(categoryForm) });
      toast.success(editingItem ? 'Atualizado!' : 'Criado!');
      setShowModal(null); fetchData();
    } catch { toast.error('Erro'); }
    finally { setSaving(false); }
  };

  const deleteCategory = async (category) => {
    const count = products.filter(p => p.categoryId === category.id).length;
    if (count > 0) { toast.error('Remova os produtos primeiro'); return; }
    if (!confirm(`Excluir "${category.name}"?`)) return;
    try {
      await fetch(`/api/admin/categories/${category.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      toast.success('Excluído'); fetchData();
    } catch { toast.error('Erro'); }
  };

  const toggleTag = (tag) => {
    setProductForm(prev => ({ ...prev, tags: prev.tags.includes(tag) ? prev.tags.filter(t => t !== tag) : [...prev.tags, tag] }));
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-100 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-emerald-500" /></div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 pb-20 md:pb-0">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link href="/admin/dashboard">
                <Button variant="ghost" size="icon" className="h-8 w-8"><ArrowLeft className="w-4 h-4" /></Button>
              </Link>
              <h1 className="text-lg font-bold">Cardápio</h1>
            </div>
            <div className="flex gap-1">
              <Button size="sm" variant={activeTab === 'products' ? 'default' : 'outline'} onClick={() => setActiveTab('products')} className="text-xs h-8">
                <Package className="w-3 h-3 mr-1" /> {products.length}
              </Button>
              <Button size="sm" variant={activeTab === 'categories' ? 'default' : 'outline'} onClick={() => setActiveTab('categories')} className="text-xs h-8">
                <LayoutGrid className="w-3 h-3 mr-1" /> {categories.length}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="p-4 max-w-6xl mx-auto">
        {/* Products */}
        {activeTab === 'products' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold">Produtos</h2>
              <Button size="sm" onClick={() => openProductModal()} className="bg-emerald-500 hover:bg-emerald-600">
                <Plus className="w-4 h-4 mr-1" /> Novo
              </Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {products.map(product => {
                const cat = categories.find(c => c.id === product.categoryId);
                return (
                  <Card key={product.id} className={!product.available ? 'opacity-50' : ''}>
                    <CardContent className="p-3">
                      <div className="flex gap-3">
                        {product.image && <img src={product.image} alt="" className="w-16 h-16 rounded object-cover flex-shrink-0" />}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-1">
                            <h3 className="font-medium text-sm truncate">{product.name}</h3>
                            <span className="text-sm font-bold text-emerald-600 flex-shrink-0">R${product.price.toFixed(0)}</span>
                          </div>
                          <p className="text-xs text-gray-500">{cat?.icon} {cat?.name}</p>
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {product.tags?.map(tag => {
                              const t = TAGS.find(x => x.value === tag);
                              return t && <span key={tag} className={`text-[9px] px-1 rounded ${t.color}`}>{t.label}</span>;
                            })}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-2 pt-2 border-t">
                        <div className="flex items-center gap-2">
                          <Switch checked={product.available} onCheckedChange={() => toggleAvailability(product)} />
                          <span className="text-xs text-gray-500">{product.available ? 'On' : 'Off'}</span>
                        </div>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openProductModal(product)}><Pencil className="w-3 h-3" /></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteProduct(product)}><Trash2 className="w-3 h-3" /></Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </>
        )}

        {/* Categories */}
        {activeTab === 'categories' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold">Categorias</h2>
              <Button size="sm" onClick={() => openCategoryModal()} className="bg-emerald-500 hover:bg-emerald-600">
                <Plus className="w-4 h-4 mr-1" /> Nova
              </Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {categories.map(cat => {
                const count = products.filter(p => p.categoryId === cat.id).length;
                return (
                  <Card key={cat.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{cat.icon}</span>
                          <div>
                            <h3 className="font-medium">{cat.name}</h3>
                            <p className="text-xs text-gray-500">{count} produtos</p>
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openCategoryModal(cat)}><Pencil className="w-4 h-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => deleteCategory(cat)} disabled={count > 0}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </>
        )}
      </main>

      {/* Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="grid grid-cols-4 gap-1 p-2">
          <Link href="/admin/dashboard"><Button variant="ghost" className="w-full flex-col h-auto py-2"><Home className="w-5 h-5" /><span className="text-[10px] mt-1">Início</span></Button></Link>
          <Link href="/admin/cozinha"><Button variant="ghost" className="w-full flex-col h-auto py-2"><ChefHat className="w-5 h-5" /><span className="text-[10px] mt-1">Cozinha</span></Button></Link>
          <Link href="/admin/cardapio"><Button variant="ghost" className="w-full flex-col h-auto py-2 text-emerald-600"><Package className="w-5 h-5" /><span className="text-[10px] mt-1">Cardápio</span></Button></Link>
          <Link href="/admin/mesas"><Button variant="ghost" className="w-full flex-col h-auto py-2"><QrCode className="w-5 h-5" /><span className="text-[10px] mt-1">QR Codes</span></Button></Link>
        </div>
      </nav>

      {/* Product Modal */}
      {showModal === 'product' && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
          <Card className="w-full sm:max-w-lg max-h-[90vh] rounded-t-2xl sm:rounded-xl overflow-hidden">
            <CardHeader className="py-3 px-4 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{editingItem ? 'Editar' : 'Novo'} Produto</CardTitle>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowModal(null)}><X className="w-4 h-4" /></Button>
              </div>
            </CardHeader>
            <ScrollArea className="max-h-[60vh]">
              <div className="p-4 space-y-4">
                <div><Label className="text-xs">Nome *</Label><Input value={productForm.name} onChange={e => setProductForm({ ...productForm, name: e.target.value })} placeholder="Ex: Picanha" className="mt-1" /></div>
                <div><Label className="text-xs">Categoria *</Label>
                  <Select value={productForm.categoryId} onValueChange={v => setProductForm({ ...productForm, categoryId: v })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>{categories.map(c => <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">Preço *</Label>
                  <div className="relative mt-1"><DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input type="number" step="0.01" value={productForm.price} onChange={e => setProductForm({ ...productForm, price: e.target.value })} className="pl-10" /></div>
                </div>
                <div><Label className="text-xs">Descrição</Label><Textarea value={productForm.description} onChange={e => setProductForm({ ...productForm, description: e.target.value })} rows={2} className="mt-1" /></div>
                <div><Label className="text-xs">URL Imagem</Label><Input value={productForm.image} onChange={e => setProductForm({ ...productForm, image: e.target.value })} placeholder="https://..." className="mt-1" /></div>
                <div><Label className="text-xs">Tags</Label>
                  <div className="flex gap-2 flex-wrap mt-1">
                    {TAGS.map(tag => <Badge key={tag.value} variant={productForm.tags.includes(tag.value) ? 'default' : 'outline'} className={`cursor-pointer ${productForm.tags.includes(tag.value) ? tag.color : ''}`} onClick={() => toggleTag(tag.value)}>{tag.label}</Badge>)}
                  </div>
                </div>
              </div>
            </ScrollArea>
            <div className="p-4 border-t flex gap-2">
              <Button variant="outline" onClick={() => setShowModal(null)} className="flex-1">Cancelar</Button>
              <Button onClick={saveProduct} disabled={saving} className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4 mr-1" />Salvar</>}
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Category Modal */}
      {showModal === 'category' && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
          <Card className="w-full sm:max-w-md rounded-t-2xl sm:rounded-xl">
            <CardHeader className="py-3 px-4 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{editingItem ? 'Editar' : 'Nova'} Categoria</CardTitle>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowModal(null)}><X className="w-4 h-4" /></Button>
              </div>
            </CardHeader>
            <div className="p-4 space-y-4">
              <div><Label className="text-xs">Nome *</Label><Input value={categoryForm.name} onChange={e => setCategoryForm({ ...categoryForm, name: e.target.value })} placeholder="Ex: Pratos Principais" className="mt-1" /></div>
              <div><Label className="text-xs">Ícone (Emoji)</Label><Input value={categoryForm.icon} onChange={e => setCategoryForm({ ...categoryForm, icon: e.target.value })} placeholder="🍝" className="mt-1" /></div>
            </div>
            <div className="p-4 border-t flex gap-2">
              <Button variant="outline" onClick={() => setShowModal(null)} className="flex-1">Cancelar</Button>
              <Button onClick={saveCategory} disabled={saving} className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4 mr-1" />Salvar</>}
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
