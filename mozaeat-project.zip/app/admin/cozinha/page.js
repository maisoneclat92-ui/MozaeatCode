'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { toast } from 'sonner';
import { 
  ChefHat, Clock, CheckCircle2, Loader2, ArrowLeft,
  UtensilsCrossed, ArrowRight, Trash2, Volume2, VolumeX, RefreshCw, Bell,
  CreditCard, Banknote, Smartphone, X, AlertTriangle
} from 'lucide-react';

const STATUS_CONFIG = {
  new: { label: 'Novo', color: 'bg-red-500', next: 'preparing' },
  preparing: { label: 'Preparando', color: 'bg-yellow-500', next: 'ready' },
  ready: { label: 'Pronto', color: 'bg-green-500', next: 'delivered' },
  delivered: { label: 'Entregue', color: 'bg-gray-400', next: null }
};

const PAYMENT_ICONS = {
  card: CreditCard,
  cash: Banknote,
  pix: Smartphone
};

const PAYMENT_LABELS = {
  card: 'Cartão',
  cash: 'Dinheiro',
  pix: 'Pix'
};

export default function KitchenPage() {
  const router = useRouter();
  const [orders, setOrders] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [restaurant, setRestaurant] = useState(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [connected, setConnected] = useState(false);
  const [activeTab, setActiveTab] = useState('new');
  const orderAudioRef = useRef(null);
  const alertAudioRef = useRef(null);
  const eventSourceRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    const rest = localStorage.getItem('admin_restaurant');
    
    if (!token) {
      router.push('/admin');
      return;
    }
    
    if (rest) setRestaurant(JSON.parse(rest));
    
    // Different sounds for orders vs alerts
    orderAudioRef.current = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2teleQ0LSJnT5pl1Cg49k9HrlHwKDUSNz+2TgQoRRYnM7pGCCxRFh8vvkYMKFUWGyu+RgwoVRYbK75GDChVFhsrvkYMKFUWGyu+RgwoVRYbK75GDChVFhsrvkYMKFkWGyu+RgwoWRYbK75GDChZFhsrvkYMKFkWGyu+RgwoWRYbK75GDChZFhsrvkYMKF0WGyu+RgwoXRYbK75GDChdFhsrvkYMKF0WGyu+RgwoXRYbK75GDChdFhsrvkYMKGEWGyu+RgwoYRYbK75GDChhFhsrvkYMKGEWGyu+RgwoYRYbK75GDChhFhsrvkYMKGUWGyu+RgwoZRYbK75GDChlFhsrvkYMKGUWGyu+RgwoZRYbK75GDChpFhsrvkYMKGkWGyu+RgwoaRYbK75GDChpFhsrvkYMKGkWGyu+RgwoaRYbK75GDChpFhsrvkYMKG0WGyu+RgwobRYbK75GDChtFhsrvkYMKG0WGyu+RgwobRYbK75GDChtFhsrvkYMKHEWGyu+RgwocRYbK75GDChxFhsrvkYMKHEWGyu+RgwocRYbK75GDChxFhsrvkYMKHEWGyu+Rgw==');
    // Alert sound (higher pitch, more urgent)
    alertAudioRef.current = new Audio('data:audio/wav;base64,UklGRl9vT19teleQ0LSJnT5pl1Cg49k9HrlHwKDUSNz+2TgQoRRYnM7pGCCxRFh8vvkYMKFUWGyu+RgwoVRYbK75GDChVFhsrvkYMKFUWGyu+RgwoVRYbK75GDChVFhsrvkYMKFkWGyu+RgwoWRYbK75GDChZFhsrvkYMKFkWGyu+RgwoWRYbK75GDChZFhsrvkYMKF0WGyu+RgwoXRYbK75GDChdFhsrvkYMK');
    
    fetchOrders(token);
    fetchAlerts(token);
    connectSSE(token);
    
    return () => {
      if (eventSourceRef.current) eventSourceRef.current.close();
    };
  }, [router]);

  const playOrderSound = useCallback(() => {
    if (soundEnabled && orderAudioRef.current) {
      orderAudioRef.current.currentTime = 0;
      orderAudioRef.current.play().catch(() => {});
    }
  }, [soundEnabled]);

  const playAlertSound = useCallback(() => {
    if (soundEnabled && alertAudioRef.current) {
      alertAudioRef.current.currentTime = 0;
      alertAudioRef.current.play().catch(() => {});
      // Play twice for urgency
      setTimeout(() => {
        alertAudioRef.current.currentTime = 0;
        alertAudioRef.current.play().catch(() => {});
      }, 300);
    }
  }, [soundEnabled]);

  const fetchOrders = async (token) => {
    try {
      const response = await fetch('/api/admin/orders', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setOrders(data.filter(o => o.status !== 'delivered'));
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAlerts = async (token) => {
    try {
      const response = await fetch('/api/admin/alerts', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        setAlerts(await response.json());
      }
    } catch (error) {
      console.error('Error fetching alerts:', error);
    }
  };

  const connectSSE = (token) => {
    if (eventSourceRef.current) eventSourceRef.current.close();

    const rest = JSON.parse(localStorage.getItem('admin_restaurant') || '{}');
    const eventSource = new EventSource(`/api/admin/orders/stream?restaurantId=${rest.id}`);
    eventSourceRef.current = eventSource;

    eventSource.onopen = () => setConnected(true);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'new_order') {
          setOrders(prev => [data.order, ...prev.filter(o => o.id !== data.order.id)]);
          playOrderSound();
          toast.success(`🍽️ Novo pedido! Mesa ${data.order.tableNumber}`, { duration: 5000 });
        } else if (data.type === 'order_updated') {
          setOrders(prev => {
            if (data.order.status === 'delivered') return prev.filter(o => o.id !== data.order.id);
            return prev.map(o => o.id === data.order.id ? data.order : o);
          });
        } else if (data.type === 'order_deleted') {
          setOrders(prev => prev.filter(o => o.id !== data.orderId));
        } else if (data.type === 'waiter_call') {
          setAlerts(prev => [data.alert, ...prev]);
          playAlertSound();
          toast.warning(`🔔 Mesa ${data.alert.tableNumber} chamou o empregado!`, { duration: 10000 });
        } else if (data.type === 'bill_request') {
          setAlerts(prev => [data.alert, ...prev]);
          playAlertSound();
          toast.warning(`💳 Mesa ${data.alert.tableNumber} pediu a conta (${PAYMENT_LABELS[data.alert.paymentMethod]})!`, { duration: 10000 });
        } else if (data.type === 'alert_dismissed') {
          setAlerts(prev => prev.filter(a => a.id !== data.alertId));
        }
      } catch (e) {}
    };

    eventSource.onerror = () => {
      setConnected(false);
      eventSource.close();
      setTimeout(() => connectSSE(token), 3000);
    };
  };

  const updateStatus = async (orderId, newStatus) => {
    const token = localStorage.getItem('admin_token');
    try {
      await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status: newStatus })
      });
      toast.success(`Pedido ${STATUS_CONFIG[newStatus].label.toLowerCase()}!`);
    } catch (error) {
      toast.error('Erro ao atualizar');
    }
  };

  const deleteOrder = async (orderId) => {
    if (!confirm('Excluir pedido?')) return;
    const token = localStorage.getItem('admin_token');
    try {
      await fetch(`/api/admin/orders/${orderId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success('Excluído');
    } catch (error) {
      toast.error('Erro');
    }
  };

  const dismissAlert = async (alertId) => {
    const token = localStorage.getItem('admin_token');
    try {
      await fetch(`/api/admin/alerts/${alertId}/dismiss`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });
      setAlerts(prev => prev.filter(a => a.id !== alertId));
    } catch (error) {
      toast.error('Erro');
    }
  };

  const getTimeSince = (dateStr) => {
    const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000 / 60);
    if (diff < 1) return 'Agora';
    if (diff < 60) return `${diff}min`;
    return `${Math.floor(diff / 60)}h${diff % 60}m`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-emerald-500" />
      </div>
    );
  }

  const newOrders = orders.filter(o => o.status === 'new');
  const preparingOrders = orders.filter(o => o.status === 'preparing');
  const readyOrders = orders.filter(o => o.status === 'ready');
  const tabOrders = { new: newOrders, preparing: preparingOrders, ready: readyOrders };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Alerts Bar */}
      {alerts.length > 0 && (
        <div className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white">
          <div className="px-3 py-2 overflow-x-auto">
            <div className="flex gap-2">
              {alerts.map(alert => {
                const PaymentIcon = PAYMENT_ICONS[alert.paymentMethod] || Bell;
                return (
                  <div 
                    key={alert.id} 
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg flex-shrink-0 ${
                      alert.type === 'bill' ? 'bg-red-600' : 'bg-blue-600'
                    }`}
                  >
                    {alert.type === 'waiter' ? (
                      <Bell className="w-4 h-4 animate-pulse" />
                    ) : (
                      <PaymentIcon className="w-4 h-4" />
                    )}
                    <span className="font-bold">Mesa {alert.tableNumber}</span>
                    <span className="text-xs opacity-80">
                      {alert.type === 'waiter' ? 'Empregado' : PAYMENT_LABELS[alert.paymentMethod]}
                    </span>
                    <button 
                      onClick={() => dismissAlert(alert.id)}
                      className="ml-1 p-0.5 hover:bg-white/20 rounded"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
        <div className="px-3 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link href="/admin/dashboard">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white h-8 w-8">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <ChefHat className="w-6 h-6 text-emerald-500" />
              <div>
                <h1 className="text-sm font-bold text-white">KDS</h1>
                <p className="text-[10px] text-gray-400 hidden sm:block">{restaurant?.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {/* Alert indicator */}
              {alerts.length > 0 && (
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-yellow-500/20 text-yellow-400 mr-2">
                  <AlertTriangle className="w-3 h-3 animate-pulse" />
                  {alerts.length}
                </div>
              )}
              <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${connected ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
                <span className="hidden sm:inline">{connected ? 'Online' : '...'}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSoundEnabled(!soundEnabled)} className="text-gray-400 hover:text-white h-8 w-8">
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => { fetchOrders(localStorage.getItem('admin_token')); fetchAlerts(localStorage.getItem('admin_token')); }} className="text-gray-400 hover:text-white h-8 w-8">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Tabs */}
        <div className="lg:hidden flex border-t border-gray-700">
          {['new', 'preparing', 'ready'].map(tab => {
            const count = tabOrders[tab].length;
            const config = STATUS_CONFIG[tab];
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 text-center text-xs font-medium relative
                  ${activeTab === tab ? 'text-white' : 'text-gray-500'}`}
              >
                <span className={`inline-flex items-center gap-1`}>
                  <span className={`w-2 h-2 rounded-full ${config.color} ${tab === 'new' && count > 0 ? 'animate-pulse' : ''}`} />
                  {config.label} ({count})
                </span>
                {activeTab === tab && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />}
              </button>
            );
          })}
        </div>
      </header>

      {/* Desktop: 3 columns | Mobile: Tabs */}
      <main className="p-2 lg:p-4">
        {/* Desktop View */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-4">
          {['new', 'preparing', 'ready'].map(status => {
            const statusOrders = tabOrders[status];
            const config = STATUS_CONFIG[status];
            return (
              <div key={status}>
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-3 h-3 rounded-full ${config.color} ${status === 'new' ? 'animate-pulse' : ''}`} />
                  <h2 className="text-sm font-bold text-white">{config.label} ({statusOrders.length})</h2>
                </div>
                <div className="space-y-3">
                  {statusOrders.map(order => (
                    <OrderCard key={order.id} order={order} onStatusChange={updateStatus} onDelete={deleteOrder} getTimeSince={getTimeSince} />
                  ))}
                  {statusOrders.length === 0 && (
                    <div className="text-center py-8 text-gray-600">
                      <div className="w-10 h-10 mx-auto mb-2 opacity-30">
                        {status === 'new' ? <Bell className="w-full h-full" /> : status === 'preparing' ? <UtensilsCrossed className="w-full h-full" /> : <CheckCircle2 className="w-full h-full" />}
                      </div>
                      <p className="text-xs">Vazio</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile View */}
        <div className="lg:hidden space-y-3">
          {tabOrders[activeTab].map(order => (
            <OrderCard key={order.id} order={order} onStatusChange={updateStatus} onDelete={deleteOrder} getTimeSince={getTimeSince} />
          ))}
          {tabOrders[activeTab].length === 0 && (
            <div className="text-center py-12 text-gray-600">
              <div className="w-16 h-16 mx-auto mb-3 opacity-30">
                {activeTab === 'new' ? <Bell className="w-full h-full" /> : activeTab === 'preparing' ? <UtensilsCrossed className="w-full h-full" /> : <CheckCircle2 className="w-full h-full" />}
              </div>
              <p className="text-sm">Nenhum pedido {STATUS_CONFIG[activeTab].label.toLowerCase()}</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function OrderCard({ order, onStatusChange, onDelete, getTimeSince }) {
  const config = STATUS_CONFIG[order.status];
  const nextStatus = config.next;
  const nextConfig = nextStatus ? STATUS_CONFIG[nextStatus] : null;

  return (
    <Card className="bg-gray-800 border-gray-700 overflow-hidden">
      <CardHeader className={`py-2 px-3 ${config.color}`}>
        <div className="flex items-center justify-between text-white">
          <span className="text-xl font-bold">Mesa {order.tableNumber}</span>
          <div className="flex items-center gap-1 text-xs opacity-90">
            <Clock className="w-3 h-3" />
            {getTimeSince(order.createdAt)}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-3">
        <div className="space-y-1 mb-3">
          {order.items.map((item, idx) => (
            <div key={idx} className="text-white text-sm">
              <span className="font-bold text-emerald-400">{item.quantity}x</span> {item.name}
            </div>
          ))}
        </div>
        
        <div className="flex gap-2">
          {nextStatus && (
            <Button
              onClick={() => onStatusChange(order.id, nextStatus)}
              size="sm"
              className={`flex-1 ${nextStatus === 'preparing' ? 'bg-yellow-500 hover:bg-yellow-600' : nextStatus === 'ready' ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-500'}`}
            >
              {nextConfig?.label}
              <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          )}
          <Button variant="ghost" size="icon" onClick={() => onDelete(order.id)} className="text-red-400 hover:text-red-300 h-8 w-8">
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
