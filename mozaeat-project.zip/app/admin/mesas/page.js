'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { 
  ArrowLeft, Plus, Trash2, Loader2, QrCode, Download,
  ExternalLink, Printer, Grid3X3, Home, ChefHat, Package, X
} from 'lucide-react';

export default function MesasPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [tables, setTables] = useState([]);
  const [restaurant, setRestaurant] = useState(null);
  const [newTableNumber, setNewTableNumber] = useState('');
  const [adding, setAdding] = useState(false);
  const [showQRModal, setShowQRModal] = useState(null);

  const token = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';

  useEffect(() => {
    if (!token) { router.push('/admin'); return; }
    const rest = localStorage.getItem('admin_restaurant');
    if (rest) setRestaurant(JSON.parse(rest));
    fetchTables();
  }, [router, token]);

  const fetchTables = async () => {
    try {
      const response = await fetch('/api/admin/tables', { headers: { Authorization: `Bearer ${token}` } });
      if (response.ok) setTables(await response.json());
    } catch { toast.error('Erro ao carregar'); }
    finally { setLoading(false); }
  };

  const addTable = async () => {
    const number = parseInt(newTableNumber);
    if (!number || number < 1) { toast.error('Número inválido'); return; }
    setAdding(true);
    try {
      const response = await fetch('/api/admin/tables', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ number })
      });
      if (!response.ok) throw new Error((await response.json()).error);
      toast.success(`Mesa ${number} criada!`);
      setNewTableNumber('');
      fetchTables();
    } catch (e) { toast.error(e.message || 'Erro'); }
    finally { setAdding(false); }
  };

  const deleteTable = async (table) => {
    if (!confirm(`Excluir mesa ${table.number}?`)) return;
    try {
      await fetch(`/api/admin/tables/${table.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      toast.success('Excluída'); fetchTables();
    } catch { toast.error('Erro'); }
  };

  const getTableUrl = (n) => `${baseUrl}/${restaurant?.slug}/mesa/${n}`;
  const getQRCodeUrl = (n) => `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(getTableUrl(n))}`;

  const downloadQR = async (n) => {
    const response = await fetch(getQRCodeUrl(n));
    const blob = await response.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `mesa-${n}-qrcode.png`;
    link.click();
  };

  const printAll = () => {
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>QR Codes - ${restaurant?.name}</title>
      <style>body{font-family:Arial;padding:20px}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px}
      .qr{text-align:center;border:2px solid #ddd;padding:15px;border-radius:10px;page-break-inside:avoid}
      .qr img{width:180px;height:180px}.qr h2{margin:8px 0 4px;font-size:20px}.qr p{margin:0;color:#666;font-size:12px}
      @media print{.grid{grid-template-columns:repeat(2,1fr)}}</style></head>
      <body><h1 style="text-align:center;margin-bottom:20px">${restaurant?.name}</h1><div class="grid">
      ${tables.map(t => `<div class="qr"><img src="${getQRCodeUrl(t.number)}"/><h2>Mesa ${t.number}</h2><p>Escaneie para pedir</p></div>`).join('')}
      </div><script>window.print()</script></body></html>`);
    w.document.close();
  };

  if (loading) return <div className="min-h-screen bg-gray-100 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-emerald-500" /></div>;

  return (
    <div className="min-h-screen bg-gray-100 pb-20 md:pb-0">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link href="/admin/dashboard"><Button variant="ghost" size="icon" className="h-8 w-8"><ArrowLeft className="w-4 h-4" /></Button></Link>
              <h1 className="text-lg font-bold">Mesas & QR</h1>
            </div>
            <Button size="sm" onClick={printAll} className="bg-purple-600 hover:bg-purple-700 text-xs h-8">
              <Printer className="w-3 h-3 mr-1" /> Imprimir
            </Button>
          </div>
        </div>
      </header>

      <main className="p-4 max-w-6xl mx-auto">
        {/* Add Table */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="flex gap-2">
              <Input type="number" min="1" placeholder="Nº da mesa" value={newTableNumber} onChange={e => setNewTableNumber(e.target.value)} 
                onKeyDown={e => e.key === 'Enter' && addTable()} className="flex-1" />
              <Button onClick={addTable} disabled={adding} className="bg-emerald-500 hover:bg-emerald-600">
                {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Plus className="w-4 h-4 mr-1" />Add</>}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tables Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {tables.map(table => (
            <Card key={table.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-3 text-center">
                <div className="cursor-pointer" onClick={() => setShowQRModal(table)}>
                  <img src={getQRCodeUrl(table.number)} alt="" className="w-full aspect-square rounded-lg mb-2" />
                </div>
                <h3 className="font-bold mb-2">Mesa {table.number}</h3>
                <div className="flex gap-1 justify-center">
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => downloadQR(table.number)}><Download className="w-4 h-4" /></Button>
                  <Link href={getTableUrl(table.number)} target="_blank"><Button variant="outline" size="icon" className="h-8 w-8"><ExternalLink className="w-4 h-4" /></Button></Link>
                  <Button variant="outline" size="icon" className="h-8 w-8 text-red-500" onClick={() => deleteTable(table)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {tables.length === 0 && (
          <div className="text-center py-12"><Grid3X3 className="w-16 h-16 text-gray-300 mx-auto mb-4" /><p className="text-gray-500">Nenhuma mesa</p></div>
        )}
      </main>

      {/* Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="grid grid-cols-4 gap-1 p-2">
          <Link href="/admin/dashboard"><Button variant="ghost" className="w-full flex-col h-auto py-2"><Home className="w-5 h-5" /><span className="text-[10px] mt-1">Início</span></Button></Link>
          <Link href="/admin/cozinha"><Button variant="ghost" className="w-full flex-col h-auto py-2"><ChefHat className="w-5 h-5" /><span className="text-[10px] mt-1">Cozinha</span></Button></Link>
          <Link href="/admin/cardapio"><Button variant="ghost" className="w-full flex-col h-auto py-2"><Package className="w-5 h-5" /><span className="text-[10px] mt-1">Cardápio</span></Button></Link>
          <Link href="/admin/mesas"><Button variant="ghost" className="w-full flex-col h-auto py-2 text-emerald-600"><QrCode className="w-5 h-5" /><span className="text-[10px] mt-1">QR Codes</span></Button></Link>
        </div>
      </nav>

      {/* QR Modal */}
      {showQRModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setShowQRModal(null)}>
          <Card className="w-full max-w-xs" onClick={e => e.stopPropagation()}>
            <CardHeader className="py-2 px-4 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Mesa {showQRModal.number}</CardTitle>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowQRModal(null)}><X className="w-4 h-4" /></Button>
              </div>
            </CardHeader>
            <CardContent className="p-4 text-center">
              <img src={getQRCodeUrl(showQRModal.number)} alt="" className="w-48 mx-auto rounded-lg mb-3" />
              <p className="text-xs text-gray-400 mb-3 break-all">{getTableUrl(showQRModal.number)}</p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 text-xs" onClick={() => { navigator.clipboard.writeText(getTableUrl(showQRModal.number)); toast.success('Copiado!'); }}>Copiar</Button>
                <Button className="flex-1 text-xs bg-emerald-500" onClick={() => downloadQR(showQRModal.number)}><Download className="w-3 h-3 mr-1" />Baixar</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
