'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Check, Loader2, ArrowLeft, Utensils, Crown, Shield, X, Star } from 'lucide-react';

const PLAN = {
  id: 'gourmet',
  name: 'Plano Gourmet',
  description: 'Tudo que você precisa para digitalizar seu restaurante',
  price: 5000,
  currency: 'MZN',
  features: [
    'Mesas ilimitadas',
    'Menu digital completo',
    'Pedidos em tempo real',
    'QR Codes personalizados',
    'KDS (Kitchen Display System)',
    'Fotos nos produtos',
    'Múltiplos usuários',
    'Relatórios e estatísticas',
    'Suporte prioritário'
  ]
};

export default function PlanosPage() {
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    restaurantName: '',
    name: '',
    email: '',
    password: ''
  });

  const handleSubscribe = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!form.restaurantName || !form.name || !form.email || !form.password) {
        throw new Error('Preencha todos os campos');
      }

      if (form.password.length < 6) {
        throw new Error('A senha deve ter pelo menos 6 caracteres');
      }

      const response = await fetch('/api/stripe/checkout-with-registration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: PLAN.id,
          ...form
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao processar');
      }

      window.location.href = data.url;
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => price.toLocaleString('pt-MZ');

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="w-5 h-5 text-gray-500" />
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                <Utensils className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">MozaEat</span>
            </div>
          </Link>
          <Link href="/admin">
            <Button variant="outline" size="sm">Já tenho conta</Button>
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-12 max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Star className="w-4 h-4" />
            Plano Único
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">
            Digitalize seu restaurante
          </h1>
          <p className="text-gray-600 text-lg">
            Um plano completo, sem surpresas
          </p>
        </div>

        {/* Plan Card */}
        <Card className="relative overflow-hidden border-2 border-emerald-200 shadow-xl">
          <div className="h-2 bg-gradient-to-r from-emerald-500 to-teal-600" />
          
          <CardHeader className="text-center pb-2 pt-8">
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/25">
              <Crown className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-2xl">{PLAN.name}</CardTitle>
            <CardDescription className="text-base">{PLAN.description}</CardDescription>
          </CardHeader>
          
          <CardContent className="pt-4">
            <div className="text-center mb-6">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-5xl font-bold text-gray-900">{formatPrice(PLAN.price)}</span>
                <span className="text-xl text-gray-500">{PLAN.currency}</span>
              </div>
              <span className="text-gray-500">por mês</span>
            </div>

            <div className="grid sm:grid-cols-2 gap-3 mb-8">
              {PLAN.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <div className="w-5 h-5 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-emerald-600" />
                  </div>
                  <span>{feature}</span>
                </div>
              ))}
            </div>

            <Button
              size="lg"
              className="w-full h-14 text-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg shadow-emerald-500/25 rounded-full"
              onClick={() => setShowForm(true)}
            >
              Assinar Agora
            </Button>

            <div className="flex items-center justify-center gap-2 mt-4 text-sm text-gray-500">
              <Shield className="w-4 h-4" />
              <span>Pagamento seguro via Stripe</span>
            </div>
          </CardContent>
        </Card>

        {/* FAQ */}
        <div className="mt-12">
          <h2 className="text-xl font-semibold text-center mb-6">Dúvidas frequentes</h2>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1">Como funciona?</h3>
                <p className="text-sm text-gray-600">Preencha seus dados, faça o pagamento e receba suas credenciais por email. Simples assim!</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1">Posso cancelar a qualquer momento?</h3>
                <p className="text-sm text-gray-600">Sim! Cancele quando quiser, sem multas. Seu acesso continua até o fim do período pago.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1">Quais formas de pagamento?</h3>
                <p className="text-sm text-gray-600">Aceitamos cartões Visa, Mastercard e outros cartões internacionais.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Registration Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
          <Card className="w-full max-w-md rounded-t-2xl sm:rounded-xl max-h-[90vh] overflow-auto animate-in slide-in-from-bottom duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Dados do Restaurante</CardTitle>
                  <CardDescription>Preencha para continuar com o pagamento</CardDescription>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setShowForm(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubscribe} className="space-y-4">
                <div>
                  <Label className="text-sm">Nome do Restaurante *</Label>
                  <Input
                    placeholder="Ex: Pizzaria do Zé"
                    value={form.restaurantName}
                    onChange={(e) => setForm({ ...form, restaurantName: e.target.value })}
                    required
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-sm">Seu Nome *</Label>
                  <Input
                    placeholder="João Silva"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    required
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-sm">Email *</Label>
                  <Input
                    type="email"
                    placeholder="joao@email.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    required
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">Suas credenciais serão enviadas para este email</p>
                </div>
                <div>
                  <Label className="text-sm">Senha de Acesso *</Label>
                  <Input
                    type="password"
                    placeholder="Mínimo 6 caracteres"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    required
                    className="mt-1"
                  />
                </div>

                <div className="bg-emerald-50 rounded-lg p-3 text-sm border border-emerald-200">
                  <p className="font-medium text-emerald-800">Resumo:</p>
                  <p className="text-emerald-700">Plano Gourmet - {formatPrice(PLAN.price)} {PLAN.currency}/mês</p>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full h-12 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-full"
                  disabled={loading}
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'Continuar para Pagamento'
                  )}
                </Button>

                <p className="text-xs text-center text-gray-500">
                  Ao continuar, você concorda com os termos de uso
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
