'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  QrCode, ChefHat, ArrowRight, Smartphone, Clock, 
  Check, Star, Menu, X, Play, Users, TrendingUp,
  Zap, Shield, BarChart3, Bell, CreditCard, Utensils,
  ChevronDown, MessageCircle, Mail, MapPin, Phone
} from 'lucide-react';

// Animated counter component
function AnimatedCounter({ target, suffix = '', duration = 2000 }) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime;
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };
    requestAnimationFrame(step);
  }, [isVisible, target, duration]);

  return <span ref={ref}>{count}{suffix}</span>;
}

// Scroll reveal component
function ScrollReveal({ children, className = '', delay = 0 }) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [delay]);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      } ${className}`}
    >
      {children}
    </div>
  );
}

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const features = [
    {
      icon: QrCode,
      title: 'Menu Digital no QR Code',
      description: 'Cliente escaneia, vê o cardápio completo e faz pedidos direto do telemóvel. Sem app, sem fricção.',
      color: 'from-emerald-500 to-teal-500'
    },
    {
      icon: ChefHat,
      title: 'Painel de Cozinha (KDS)',
      description: 'Pedidos aparecem em tempo real na tela da cozinha. Sons de alerta e organização automática.',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      icon: CreditCard,
      title: 'Comanda Viva',
      description: 'Cliente acompanha seus pedidos e o total da conta em tempo real. Solicita empregado ou pagamento.',
      color: 'from-violet-500 to-purple-500'
    },
    {
      icon: BarChart3,
      title: 'Gestão Completa',
      description: 'Dashboard administrativo com estatísticas, gestão de cardápio, mesas e QR codes.',
      color: 'from-orange-500 to-amber-500'
    }
  ];

  const benefits = [
    {
      icon: TrendingUp,
      title: 'Aumente a Eficiência',
      description: 'Reduza em 40% o tempo de atendimento com pedidos digitais diretos para a cozinha.'
    },
    {
      icon: Users,
      title: 'Melhore a Experiência',
      description: 'Clientes adoram a praticidade de pedir pelo telemóvel sem esperar pelo empregado.'
    },
    {
      icon: Shield,
      title: 'Reduza Erros',
      description: 'Pedidos escritos pelo cliente. Sem interpretação errada, sem confusão na cozinha.'
    },
    {
      icon: Zap,
      title: 'Comece em Minutos',
      description: 'Configure seu cardápio, imprima os QR codes e comece a receber pedidos hoje.'
    }
  ];

  const steps = [
    {
      number: '01',
      title: 'Assine o Plano',
      description: 'Escolha o plano Gourmet e faça o pagamento seguro. Sua conta é criada automaticamente.'
    },
    {
      number: '02',
      title: 'Configure seu Cardápio',
      description: 'Adicione seus produtos, categorias, fotos e preços no painel administrativo.'
    },
    {
      number: '03',
      title: 'Imprima os QR Codes',
      description: 'Gere e imprima os QR codes para cada mesa do seu restaurante.'
    },
    {
      number: '04',
      title: 'Receba Pedidos',
      description: 'Clientes escaneiam, pedem e a cozinha recebe tudo em tempo real!'
    }
  ];

  const faqs = [
    {
      question: 'Como funciona o MozaEat?',
      answer: 'O cliente escaneia o QR code na mesa, vê o cardápio digital no telemóvel e faz o pedido. O pedido aparece automaticamente no painel da cozinha (KDS) em tempo real.'
    },
    {
      question: 'Preciso de equipamento especial?',
      answer: 'Não! Basta um tablet ou computador na cozinha para exibir o KDS. Os clientes usam seus próprios telemóveles.'
    },
    {
      question: 'Quanto custa?',
      answer: 'O plano Gourmet custa 5.000 MZN por mês e inclui todas as funcionalidades: mesas ilimitadas, cardápio digital, KDS, relatórios e suporte.'
    },
    {
      question: 'Posso cancelar a qualquer momento?',
      answer: 'Sim! Sem multas ou contratos de fidelidade. Cancele quando quiser e seu acesso continua até o fim do período pago.'
    },
    {
      question: 'Funciona offline?',
      answer: 'O sistema precisa de conexão com internet para funcionar, pois os pedidos são transmitidos em tempo real entre o cliente e a cozinha.'
    }
  ];

  const [openFaq, setOpenFaq] = useState(null);

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/25">
                <Utensils className="w-5 h-5 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">MozaEat</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#recursos" className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Recursos</a>
              <a href="#como-funciona" className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Como Funciona</a>
              <a href="#preco" className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Preço</a>
              <a href="#faq" className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">FAQ</a>
            </div>

            {/* CTA Buttons */}
            <div className="hidden md:flex items-center gap-3">
              <Link href="/admin">
                <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                  Entrar
                </Button>
              </Link>
              <Link href="/planos">
                <Button className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg shadow-emerald-500/25 rounded-full px-6">
                  Começar Agora
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t shadow-lg">
            <div className="px-4 py-4 space-y-3">
              <a href="#recursos" className="block py-2 text-gray-600 font-medium" onClick={() => setMobileMenuOpen(false)}>Recursos</a>
              <a href="#como-funciona" className="block py-2 text-gray-600 font-medium" onClick={() => setMobileMenuOpen(false)}>Como Funciona</a>
              <a href="#preco" className="block py-2 text-gray-600 font-medium" onClick={() => setMobileMenuOpen(false)}>Preço</a>
              <a href="#faq" className="block py-2 text-gray-600 font-medium" onClick={() => setMobileMenuOpen(false)}>FAQ</a>
              <div className="pt-3 space-y-2">
                <Link href="/admin" className="block">
                  <Button variant="outline" className="w-full">Entrar</Button>
                </Link>
                <Link href="/planos" className="block">
                  <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600">Começar Agora</Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 sm:pt-32 pb-16 sm:pb-24 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-white to-teal-50" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-100/50 to-transparent" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-teal-200/30 to-transparent rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left">
              <ScrollReveal>
                <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
                  <Zap className="w-4 h-4" />
                  Plataforma SaaS para Restaurantes
                </div>
              </ScrollReveal>

              <ScrollReveal delay={100}>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                  O Futuro do Menu e Pedido no Seu{' '}
                  <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                    Restaurante
                  </span>
                </h1>
              </ScrollReveal>

              <ScrollReveal delay={200}>
                <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0">
                  Digitalize seu cardápio, acelere o serviço e encante seus clientes com o poder do QR Code.
                </p>
              </ScrollReveal>

              <ScrollReveal delay={300}>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Link href="/planos">
                    <Button size="lg" className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-xl shadow-emerald-500/25 rounded-full px-8 h-14 text-lg w-full sm:w-auto">
                      Começar Agora
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link href="/brasserie-central/mesa/1">
                    <Button size="lg" variant="outline" className="rounded-full px-8 h-14 text-lg border-2 w-full sm:w-auto">
                      <Play className="w-5 h-5 mr-2" />
                      Ver Demo
                    </Button>
                  </Link>
                </div>
              </ScrollReveal>

              {/* Stats */}
              <ScrollReveal delay={400}>
                <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-gray-200">
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">
                      <AnimatedCounter target={500} suffix="+" />
                    </p>
                    <p className="text-sm text-gray-500">Restaurantes</p>
                  </div>
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">
                      <AnimatedCounter target={50} suffix="K+" />
                    </p>
                    <p className="text-sm text-gray-500">Pedidos/mês</p>
                  </div>
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">
                      <AnimatedCounter target={99} suffix="%" />
                    </p>
                    <p className="text-sm text-gray-500">Uptime</p>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* Right Content - Mockup */}
            <ScrollReveal delay={200} className="relative">
              <div className="relative">
                {/* Tablet Mockup - KDS */}
                <div className="relative z-10 bg-gray-900 rounded-[2rem] p-3 shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
                  <div className="bg-gray-800 rounded-[1.5rem] overflow-hidden">
                    <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full" />
                          <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                          <div className="w-3 h-3 bg-green-500 rounded-full" />
                        </div>
                        <span className="text-white/60 text-xs">Cozinha - KDS</span>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        {[
                          { table: 'Mesa 5', items: ['2x Picanha', '1x Cerveja'], status: 'new', time: '2 min' },
                          { table: 'Mesa 3', items: ['1x Frango', '2x Sumo'], status: 'preparing', time: '8 min' },
                          { table: 'Mesa 8', items: ['3x Pizza'], status: 'ready', time: '15 min' },
                        ].map((order, i) => (
                          <div key={i} className={`rounded-xl p-3 ${
                            order.status === 'new' ? 'bg-orange-500/20 border border-orange-500/50' :
                            order.status === 'preparing' ? 'bg-blue-500/20 border border-blue-500/50' :
                            'bg-green-500/20 border border-green-500/50'
                          }`}>
                            <div className="flex justify-between items-start mb-2">
                              <span className="text-white font-bold text-sm">{order.table}</span>
                              <span className="text-white/60 text-xs">{order.time}</span>
                            </div>
                            {order.items.map((item, j) => (
                              <p key={j} className="text-white/80 text-xs">{item}</p>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Phone Mockup - Customer Menu */}
                <div className="absolute -bottom-8 -left-8 z-20 w-48 bg-gray-900 rounded-[1.5rem] p-2 shadow-2xl transform -rotate-6 hover:rotate-0 transition-transform duration-500">
                  <div className="bg-white rounded-[1.25rem] overflow-hidden">
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-3">
                      <p className="text-white text-xs font-medium">Brasserie Central</p>
                      <p className="text-white/80 text-[10px]">Mesa 5</p>
                    </div>
                    <div className="p-2 space-y-2">
                      {[
                        { name: 'Picanha Grelhada', price: '650 MZN', img: 'https://images.unsplash.com/photo-1594041680534-e8c8cdebd659?w=100&h=100&fit=crop' },
                        { name: 'Frango ao Molho', price: '450 MZN', img: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=100&h=100&fit=crop' },
                        { name: 'Pizza Margherita', price: '520 MZN', img: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=100&h=100&fit=crop' }
                      ].map((item, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                          <img src={item.img} alt={item.name} className="w-8 h-8 rounded-lg object-cover" />
                          <div className="flex-1">
                            <p className="text-[10px] font-medium text-gray-900 truncate">{item.name}</p>
                            <p className="text-[8px] text-gray-500">{item.price}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-4 -right-4 bg-white rounded-2xl shadow-xl p-3 transform rotate-3 animate-pulse">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-900">Novo Pedido!</p>
                      <p className="text-[10px] text-gray-500">Mesa 5 - 2 itens</p>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="recursos" className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                Tudo que você precisa para{' '}
                <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                  digitalizar
                </span>
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Plataforma completa com todas as ferramentas essenciais para modernizar seu restaurante
              </p>
            </div>
          </ScrollReveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <ScrollReveal key={i} delay={i * 100}>
                <Card className="group h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden">
                  <CardContent className="p-6">
                    <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <ScrollReveal>
              <div>
                <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                  Para quem é o{' '}
                  <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                    MozaEat?
                  </span>
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Feito para donos de restaurantes, bares e cafés que querem modernizar o atendimento e aumentar a eficiência.
                </p>
                
                <div className="space-y-6">
                  {benefits.map((benefit, i) => (
                    <div key={i} className="flex gap-4 group">
                      <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-emerald-200 transition-colors">
                        <benefit.icon className="w-6 h-6 text-emerald-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{benefit.title}</h3>
                        <p className="text-gray-600 text-sm">{benefit.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div className="relative">
                <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-8 text-white">
                  <div className="text-center mb-6">
                    <p className="text-emerald-100 mb-2">Resultados Reais</p>
                    <p className="text-5xl font-bold mb-2">40%</p>
                    <p className="text-emerald-100">Mais rápido no atendimento</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/10 rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold">-50%</p>
                      <p className="text-xs text-emerald-100">Erros de pedido</p>
                    </div>
                    <div className="bg-white/10 rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold">+30%</p>
                      <p className="text-xs text-emerald-100">Satisfação do cliente</p>
                    </div>
                  </div>
                </div>
                {/* Decorative elements */}
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-emerald-200 rounded-full blur-2xl opacity-50" />
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-teal-200 rounded-full blur-2xl opacity-50" />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section id="como-funciona" className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                Comece em{' '}
                <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                  4 passos simples
                </span>
              </h2>
              <p className="text-lg text-gray-600">
                Configure sua conta e comece a receber pedidos em minutos
              </p>
            </div>
          </ScrollReveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, i) => (
              <ScrollReveal key={i} delay={i * 150}>
                <div className="relative">
                  {/* Connector Line */}
                  {i < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-emerald-300 to-transparent" />
                  )}
                  
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl text-white text-2xl font-bold mb-4 shadow-lg shadow-emerald-500/25">
                      {step.number}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600 text-sm">{step.description}</p>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="preco" className="py-16 sm:py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                Preço{' '}
                <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                  Simples e Transparente
                </span>
              </h2>
              <p className="text-lg text-gray-600">
                Um plano completo, sem surpresas ou taxas escondidas
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <Card className="border-2 border-emerald-200 shadow-2xl overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-emerald-500 to-teal-600" />
              <CardContent className="p-8 sm:p-12">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                    <Star className="w-4 h-4" />
                    Plano Gourmet
                  </div>
                  <div className="flex items-baseline justify-center gap-2 mb-2">
                    <span className="text-5xl sm:text-6xl font-bold text-gray-900">5.000</span>
                    <span className="text-xl text-gray-500">MZN/mês</span>
                  </div>
                  <p className="text-gray-500">Tudo incluído, sem limites</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    'Mesas ilimitadas',
                    'Menu digital completo',
                    'Pedidos em tempo real',
                    'QR Codes personalizados',
                    'KDS para cozinha',
                    'Fotos nos produtos',
                    'Múltiplos usuários',
                    'Relatórios e estatísticas',
                    'Suporte prioritário'
                  ].map((feature, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check className="w-4 h-4 text-emerald-600" />
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>

                <Link href="/planos" className="block">
                  <Button size="lg" className="w-full h-14 text-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-full shadow-xl shadow-emerald-500/25">
                    Assinar Agora
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>

                <p className="text-center text-sm text-gray-500 mt-4">
                  Cancele quando quiser. Sem compromisso.
                </p>
              </CardContent>
            </Card>
          </ScrollReveal>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                Perguntas{' '}
                <span className="bg-gradient-to-r from-emerald-500 to-teal-600 bg-clip-text text-transparent">
                  Frequentes
                </span>
              </h2>
              <p className="text-lg text-gray-600">
                Tire suas dúvidas sobre a plataforma
              </p>
            </div>
          </ScrollReveal>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <ScrollReveal key={i} delay={i * 100}>
                <Card 
                  className={`cursor-pointer transition-all duration-300 ${
                    openFaq === i ? 'shadow-lg border-emerald-200' : 'hover:shadow-md'
                  }`}
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between gap-4">
                      <h3 className="font-semibold text-gray-900">{faq.question}</h3>
                      <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 flex-shrink-0 ${
                        openFaq === i ? 'rotate-180' : ''
                      }`} />
                    </div>
                    {openFaq === i && (
                      <p className="mt-4 text-gray-600 text-sm leading-relaxed">
                        {faq.answer}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-br from-emerald-500 to-teal-600 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
              Pronto para transformar seu restaurante?
            </h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
              Junte-se a centenas de restaurantes que já estão usando MozaEat para digitalizar seus pedidos
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/planos">
                <Button size="lg" className="bg-white text-emerald-600 hover:bg-gray-100 rounded-full px-8 h-14 text-lg shadow-xl w-full sm:w-auto">
                  Começar Agora
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/brasserie-central/mesa/1">
                <Button size="lg" className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 border-2 border-white rounded-full px-8 h-14 text-lg w-full sm:w-auto">
                  Ver Demonstração
                </Button>
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                  <Utensils className="w-5 h-5 text-white" />
                </div>
                <span className="text-2xl font-bold">MozaEat</span>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                A plataforma completa para digitalizar cardápios e pedidos de restaurantes em Moçambique.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <MessageCircle className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Links */}
            <div>
              <h3 className="font-semibold mb-4">Produto</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#recursos" className="hover:text-white transition-colors">Recursos</a></li>
                <li><a href="#preco" className="hover:text-white transition-colors">Preços</a></li>
                <li><a href="#faq" className="hover:text-white transition-colors">FAQ</a></li>
                <li><Link href="/brasserie-central/mesa/1" className="hover:text-white transition-colors">Demo</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-semibold mb-4">Contacto</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  suporte@mozaeat.co.mz
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  +258 84 123 4567
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Maputo, Moçambique
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2024 MozaEat. Todos os direitos reservados.
            </p>
            <div className="flex gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-white transition-colors">Privacidade</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
